#!/bin/sh

IP=`/sbin/ifconfig eth0 | grep "inet addr:" | sed -e 's/inet addr://g' | awk '{print $1}'`

HOST=`hostname`

echo "`date` - Updating DNS with HOST - $HOST and IP - $IP" > /root/IP.txt

/bin/sed "s/IPADDRESS/$IP/g" /root/dns/dns.txt | /bin/sed "s/HOSTNAME/$HOST/g" > /root/dns/current.txt

/usr/bin/nsupdate /root/dns/current.txt >> /root/IP.txt 2>&1

REV=`echo $IP | awk -F. '{print $3"."$2"."$1}'`

LAST=`echo $IP | awk -F. '{print $4}'`

/bin/sed "s/REVERSE/$REV/g" /root/dns/dnsrev.txt | /bin/sed "s/END/$LAST/g" | /bin/sed "s/HOSTNAME/$HOST/g"  > /root/dns/currentrev.txt

/usr/bin/nsupdate /root/dns/currentrev.txt >> /root/IP.txt 2>&1
