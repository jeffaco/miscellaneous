#!/bin/sh
cp /root/dns/resolv.conf /etc/resolv.conf
cp /root/dns/resolv.conf /etc/resolv.conf.ostc
cp /root/dns/rc.local /etc/rc.d/rc.local
chmod +w /etc/rc.d/rc.local
echo "* 0 * * * /etc/rc.local > /dev/null 2>&1" >> /var/spool/cron/root
exit 0
