﻿// WSManQuery - send a WSMan WQL query request for a given namespace
// to a server and print the response on the console. Communication is
// over HTTP, not HTTPS, using basic authentication.

using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using System.Net;
using System.IO;

using Microsoft.Management.Infrastructure;
using Microsoft.Management.Infrastructure.Options;
using System.Security;

namespace WSManQuery
{
    class Program
    {
        private static void PrintCimException(CimException exception)
        {
            Console.WriteLine("Error Code = " + exception.NativeErrorCode);
            Console.WriteLine("MessageId = " + exception.MessageId);
            Console.WriteLine("Message = " + exception.Message);
            Console.WriteLine("ErrorSource = " + exception.ErrorSource);
            Console.WriteLine("ErrorType = " + exception.ErrorType);
            Console.WriteLine("Status Code = " + exception.StatusCode);

            return;
        }

        public static void PrintInstance(CimInstance cimInstance)
        {
            Console.ForegroundColor = ConsoleColor.Blue;
            Console.WriteLine("Printing non null properties for class {0} ...", cimInstance.CimSystemProperties.ClassName);
            Console.ResetColor();
            foreach (var enumeratedProperty in cimInstance.CimInstanceProperties)
            {
                bool isKey = false;
                if ((enumeratedProperty.Flags & CimFlags.Key) == CimFlags.Key)
                {
                    isKey = true;
                }

                if (enumeratedProperty.Value != null)
                {
                    if (isKey)
                    {
                        Console.ForegroundColor = ConsoleColor.Red;
                    }

                    Console.WriteLine(
                        "Name: {0}, Type: {1}, Key: {2}, Value: {3}",
                        enumeratedProperty.Name,
                        enumeratedProperty.CimType,
                        isKey,
                        enumeratedProperty.Value);
                    Console.ResetColor();
                }
            }
            return;
        }

        public static void Query(CimSession cimSession, string nameSpace, string query)
        {
            // Check Arguments
            if (nameSpace == null)
            {
                throw new ArgumentNullException("namespace");
            }

            if (query == null)
            {
                throw new ArgumentNullException("query");
            }

            try
            {
                IEnumerable<CimInstance> enumeratedInstances = cimSession.QueryInstances(nameSpace, "WQL", query);
                foreach (CimInstance cimInstance in enumeratedInstances)
                {
                    // Use the instance
                    PrintInstance(cimInstance);
                }
            }
            catch (CimException ex)
            {
                PrintCimException(ex);
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            return;
        }

        /// <summary>
        /// The main entry point
        /// </summary>
        /// <param name="args">hostname, user, password, namespace, and query for the request</param>
        static void Main(string[] args)
        {
            if (args.Length < 5) 
            {
                System.Console.WriteLine("usage: wsman _hostname_ _user_ _password_ _namespace_ _query_ [_port_]");
                return;
            }

            String host = args[0];
            String user = args[1];
            String password = args[2];
            String nameSpace = args[3];
            String query = args[4];
            UInt32 port = args.Length > 5 ? Convert.ToUInt32(args[5]) : 5986;

            SecureString sPassword = new SecureString();
            foreach (Char c in password)
            {
                sPassword.AppendChar(c);
            }

            WSManSessionOptions options = new WSManSessionOptions();
            CimCredential credential = new CimCredential(PasswordAuthenticationMechanism.Basic, "", user, sPassword);

            options.CertCACheck = false; // Most OMI certs are self-generated and so not signed by a CA
            options.CertCNCheck = false; // Frequently the OMI server's CN won't match the hostname
            options.DestinationPort = port;
            options.UseSsl = true;
            options.AddDestinationCredentials(credential);

            CimSession cimSession = CimSession.Create(host, options);
            Query(cimSession, nameSpace, query);

            return;
        }
    }
}
