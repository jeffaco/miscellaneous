import socket

# Connect to the OMI socket, easy enough
# s = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM);
# s.connect('/opt/omi-1.0.8/var/run/omiserver.sock')


print str(0xB1A87E2F)

# try:
#     while True:
#         data = s.recv(1024)
#         if not data: break
#         print 'Recevied', repr(data)
# finally:
#     s.close()
