/* @migen@ */
/*
**==============================================================================
**
** WARNING: THIS FILE WAS AUTOMATICALLY GENERATED. PLEASE DO NOT EDIT.
**
**==============================================================================
*/
#ifndef _MSFT_FileBrowser_h
#define _MSFT_FileBrowser_h

#include <MI.h>

/*
**==============================================================================
**
** MSFT_FileBrowser [MSFT_FileBrowser]
**
** Keys:
**    TargetPath
**
**==============================================================================
*/

typedef struct _MSFT_FileBrowser
{
    MI_Instance __instance;
    /* MSFT_FileBrowser properties */
    /*KEY*/ MI_ConstStringField TargetPath;
    MI_ConstStringField Function;
    MI_ConstStringField FullPath;
    MI_ConstStringField Name;
    MI_ConstStringField FolderSeparator;
    MI_ConstBooleanField PathExists;
    MI_ConstStringField AccessRights;
    MI_ConstBooleanField Directory;
    MI_ConstStringField LastAccessTimeUTC;
    MI_ConstStringField LastModificationTimeUTC;
    MI_ConstStringField LastStatusChangeTimeUTC;
    MI_ConstUint64Field LinkCount;
    MI_ConstUint64Field Size;
    MI_ConstUint64Field BlockSize;
    MI_ConstUint64Field BlockCount;
    MI_ConstUint32Field UserID;
    MI_ConstUint32Field GroupID;
    MI_ConstUint64Field Device;
    MI_ConstUint64Field DeviceNumber;
    MI_ConstUint64Field SerialNumber;
    MI_ConstUint64Field ChunkIndex;
    MI_ConstUint64Field TotalChunks;
    MI_ConstUint64Field ChunkBytes;
    MI_ConstUint64Field OffsetBytes;
    MI_ConstUint64Field TotalBytes;
    MI_ConstStringField Data;
}
MSFT_FileBrowser;

typedef struct _MSFT_FileBrowser_Ref
{
    MSFT_FileBrowser* value;
    MI_Boolean exists;
    MI_Uint8 flags;
}
MSFT_FileBrowser_Ref;

typedef struct _MSFT_FileBrowser_ConstRef
{
    MI_CONST MSFT_FileBrowser* value;
    MI_Boolean exists;
    MI_Uint8 flags;
}
MSFT_FileBrowser_ConstRef;

typedef struct _MSFT_FileBrowser_Array
{
    struct _MSFT_FileBrowser** data;
    MI_Uint32 size;
}
MSFT_FileBrowser_Array;

typedef struct _MSFT_FileBrowser_ConstArray
{
    struct _MSFT_FileBrowser MI_CONST* MI_CONST* data;
    MI_Uint32 size;
}
MSFT_FileBrowser_ConstArray;

typedef struct _MSFT_FileBrowser_ArrayRef
{
    MSFT_FileBrowser_Array value;
    MI_Boolean exists;
    MI_Uint8 flags;
}
MSFT_FileBrowser_ArrayRef;

typedef struct _MSFT_FileBrowser_ConstArrayRef
{
    MSFT_FileBrowser_ConstArray value;
    MI_Boolean exists;
    MI_Uint8 flags;
}
MSFT_FileBrowser_ConstArrayRef;

MI_EXTERN_C MI_CONST MI_ClassDecl MSFT_FileBrowser_rtti;

MI_INLINE MI_Result MI_CALL MSFT_FileBrowser_Construct(
    MSFT_FileBrowser* self,
    MI_Context* context)
{
    return MI_ConstructInstance(context, &MSFT_FileBrowser_rtti,
        (MI_Instance*)&self->__instance);
}

MI_INLINE MI_Result MI_CALL MSFT_FileBrowser_Clone(
    const MSFT_FileBrowser* self,
    MSFT_FileBrowser** newInstance)
{
    return MI_Instance_Clone(
        &self->__instance, (MI_Instance**)newInstance);
}

MI_INLINE MI_Boolean MI_CALL MSFT_FileBrowser_IsA(
    const MI_Instance* self)
{
    MI_Boolean res = MI_FALSE;
    return MI_Instance_IsA(self, &MSFT_FileBrowser_rtti, &res) == MI_RESULT_OK && res;
}

MI_INLINE MI_Result MI_CALL MSFT_FileBrowser_Destruct(MSFT_FileBrowser* self)
{
    return MI_Instance_Destruct(&self->__instance);
}

MI_INLINE MI_Result MI_CALL MSFT_FileBrowser_Delete(MSFT_FileBrowser* self)
{
    return MI_Instance_Delete(&self->__instance);
}

MI_INLINE MI_Result MI_CALL MSFT_FileBrowser_Post(
    const MSFT_FileBrowser* self,
    MI_Context* context)
{
    return MI_PostInstance(context, &self->__instance);
}

MI_INLINE MI_Result MI_CALL MSFT_FileBrowser_Set_TargetPath(
    MSFT_FileBrowser* self,
    const MI_Char* str)
{
    return self->__instance.ft->SetElementAt(
        (MI_Instance*)&self->__instance,
        0,
        (MI_Value*)&str,
        MI_STRING,
        0);
}

MI_INLINE MI_Result MI_CALL MSFT_FileBrowser_SetPtr_TargetPath(
    MSFT_FileBrowser* self,
    const MI_Char* str)
{
    return self->__instance.ft->SetElementAt(
        (MI_Instance*)&self->__instance,
        0,
        (MI_Value*)&str,
        MI_STRING,
        MI_FLAG_BORROW);
}

MI_INLINE MI_Result MI_CALL MSFT_FileBrowser_Clear_TargetPath(
    MSFT_FileBrowser* self)
{
    return self->__instance.ft->ClearElementAt(
        (MI_Instance*)&self->__instance,
        0);
}

MI_INLINE MI_Result MI_CALL MSFT_FileBrowser_Set_Function(
    MSFT_FileBrowser* self,
    const MI_Char* str)
{
    return self->__instance.ft->SetElementAt(
        (MI_Instance*)&self->__instance,
        1,
        (MI_Value*)&str,
        MI_STRING,
        0);
}

MI_INLINE MI_Result MI_CALL MSFT_FileBrowser_SetPtr_Function(
    MSFT_FileBrowser* self,
    const MI_Char* str)
{
    return self->__instance.ft->SetElementAt(
        (MI_Instance*)&self->__instance,
        1,
        (MI_Value*)&str,
        MI_STRING,
        MI_FLAG_BORROW);
}

MI_INLINE MI_Result MI_CALL MSFT_FileBrowser_Clear_Function(
    MSFT_FileBrowser* self)
{
    return self->__instance.ft->ClearElementAt(
        (MI_Instance*)&self->__instance,
        1);
}

MI_INLINE MI_Result MI_CALL MSFT_FileBrowser_Set_FullPath(
    MSFT_FileBrowser* self,
    const MI_Char* str)
{
    return self->__instance.ft->SetElementAt(
        (MI_Instance*)&self->__instance,
        2,
        (MI_Value*)&str,
        MI_STRING,
        0);
}

MI_INLINE MI_Result MI_CALL MSFT_FileBrowser_SetPtr_FullPath(
    MSFT_FileBrowser* self,
    const MI_Char* str)
{
    return self->__instance.ft->SetElementAt(
        (MI_Instance*)&self->__instance,
        2,
        (MI_Value*)&str,
        MI_STRING,
        MI_FLAG_BORROW);
}

MI_INLINE MI_Result MI_CALL MSFT_FileBrowser_Clear_FullPath(
    MSFT_FileBrowser* self)
{
    return self->__instance.ft->ClearElementAt(
        (MI_Instance*)&self->__instance,
        2);
}

MI_INLINE MI_Result MI_CALL MSFT_FileBrowser_Set_Name(
    MSFT_FileBrowser* self,
    const MI_Char* str)
{
    return self->__instance.ft->SetElementAt(
        (MI_Instance*)&self->__instance,
        3,
        (MI_Value*)&str,
        MI_STRING,
        0);
}

MI_INLINE MI_Result MI_CALL MSFT_FileBrowser_SetPtr_Name(
    MSFT_FileBrowser* self,
    const MI_Char* str)
{
    return self->__instance.ft->SetElementAt(
        (MI_Instance*)&self->__instance,
        3,
        (MI_Value*)&str,
        MI_STRING,
        MI_FLAG_BORROW);
}

MI_INLINE MI_Result MI_CALL MSFT_FileBrowser_Clear_Name(
    MSFT_FileBrowser* self)
{
    return self->__instance.ft->ClearElementAt(
        (MI_Instance*)&self->__instance,
        3);
}

MI_INLINE MI_Result MI_CALL MSFT_FileBrowser_Set_FolderSeparator(
    MSFT_FileBrowser* self,
    const MI_Char* str)
{
    return self->__instance.ft->SetElementAt(
        (MI_Instance*)&self->__instance,
        4,
        (MI_Value*)&str,
        MI_STRING,
        0);
}

MI_INLINE MI_Result MI_CALL MSFT_FileBrowser_SetPtr_FolderSeparator(
    MSFT_FileBrowser* self,
    const MI_Char* str)
{
    return self->__instance.ft->SetElementAt(
        (MI_Instance*)&self->__instance,
        4,
        (MI_Value*)&str,
        MI_STRING,
        MI_FLAG_BORROW);
}

MI_INLINE MI_Result MI_CALL MSFT_FileBrowser_Clear_FolderSeparator(
    MSFT_FileBrowser* self)
{
    return self->__instance.ft->ClearElementAt(
        (MI_Instance*)&self->__instance,
        4);
}

MI_INLINE MI_Result MI_CALL MSFT_FileBrowser_Set_PathExists(
    MSFT_FileBrowser* self,
    MI_Boolean x)
{
    ((MI_BooleanField*)&self->PathExists)->value = x;
    ((MI_BooleanField*)&self->PathExists)->exists = 1;
    return MI_RESULT_OK;
}

MI_INLINE MI_Result MI_CALL MSFT_FileBrowser_Clear_PathExists(
    MSFT_FileBrowser* self)
{
    memset((void*)&self->PathExists, 0, sizeof(self->PathExists));
    return MI_RESULT_OK;
}

MI_INLINE MI_Result MI_CALL MSFT_FileBrowser_Set_AccessRights(
    MSFT_FileBrowser* self,
    const MI_Char* str)
{
    return self->__instance.ft->SetElementAt(
        (MI_Instance*)&self->__instance,
        6,
        (MI_Value*)&str,
        MI_STRING,
        0);
}

MI_INLINE MI_Result MI_CALL MSFT_FileBrowser_SetPtr_AccessRights(
    MSFT_FileBrowser* self,
    const MI_Char* str)
{
    return self->__instance.ft->SetElementAt(
        (MI_Instance*)&self->__instance,
        6,
        (MI_Value*)&str,
        MI_STRING,
        MI_FLAG_BORROW);
}

MI_INLINE MI_Result MI_CALL MSFT_FileBrowser_Clear_AccessRights(
    MSFT_FileBrowser* self)
{
    return self->__instance.ft->ClearElementAt(
        (MI_Instance*)&self->__instance,
        6);
}

MI_INLINE MI_Result MI_CALL MSFT_FileBrowser_Set_Directory(
    MSFT_FileBrowser* self,
    MI_Boolean x)
{
    ((MI_BooleanField*)&self->Directory)->value = x;
    ((MI_BooleanField*)&self->Directory)->exists = 1;
    return MI_RESULT_OK;
}

MI_INLINE MI_Result MI_CALL MSFT_FileBrowser_Clear_Directory(
    MSFT_FileBrowser* self)
{
    memset((void*)&self->Directory, 0, sizeof(self->Directory));
    return MI_RESULT_OK;
}

MI_INLINE MI_Result MI_CALL MSFT_FileBrowser_Set_LastAccessTimeUTC(
    MSFT_FileBrowser* self,
    const MI_Char* str)
{
    return self->__instance.ft->SetElementAt(
        (MI_Instance*)&self->__instance,
        8,
        (MI_Value*)&str,
        MI_STRING,
        0);
}

MI_INLINE MI_Result MI_CALL MSFT_FileBrowser_SetPtr_LastAccessTimeUTC(
    MSFT_FileBrowser* self,
    const MI_Char* str)
{
    return self->__instance.ft->SetElementAt(
        (MI_Instance*)&self->__instance,
        8,
        (MI_Value*)&str,
        MI_STRING,
        MI_FLAG_BORROW);
}

MI_INLINE MI_Result MI_CALL MSFT_FileBrowser_Clear_LastAccessTimeUTC(
    MSFT_FileBrowser* self)
{
    return self->__instance.ft->ClearElementAt(
        (MI_Instance*)&self->__instance,
        8);
}

MI_INLINE MI_Result MI_CALL MSFT_FileBrowser_Set_LastModificationTimeUTC(
    MSFT_FileBrowser* self,
    const MI_Char* str)
{
    return self->__instance.ft->SetElementAt(
        (MI_Instance*)&self->__instance,
        9,
        (MI_Value*)&str,
        MI_STRING,
        0);
}

MI_INLINE MI_Result MI_CALL MSFT_FileBrowser_SetPtr_LastModificationTimeUTC(
    MSFT_FileBrowser* self,
    const MI_Char* str)
{
    return self->__instance.ft->SetElementAt(
        (MI_Instance*)&self->__instance,
        9,
        (MI_Value*)&str,
        MI_STRING,
        MI_FLAG_BORROW);
}

MI_INLINE MI_Result MI_CALL MSFT_FileBrowser_Clear_LastModificationTimeUTC(
    MSFT_FileBrowser* self)
{
    return self->__instance.ft->ClearElementAt(
        (MI_Instance*)&self->__instance,
        9);
}

MI_INLINE MI_Result MI_CALL MSFT_FileBrowser_Set_LastStatusChangeTimeUTC(
    MSFT_FileBrowser* self,
    const MI_Char* str)
{
    return self->__instance.ft->SetElementAt(
        (MI_Instance*)&self->__instance,
        10,
        (MI_Value*)&str,
        MI_STRING,
        0);
}

MI_INLINE MI_Result MI_CALL MSFT_FileBrowser_SetPtr_LastStatusChangeTimeUTC(
    MSFT_FileBrowser* self,
    const MI_Char* str)
{
    return self->__instance.ft->SetElementAt(
        (MI_Instance*)&self->__instance,
        10,
        (MI_Value*)&str,
        MI_STRING,
        MI_FLAG_BORROW);
}

MI_INLINE MI_Result MI_CALL MSFT_FileBrowser_Clear_LastStatusChangeTimeUTC(
    MSFT_FileBrowser* self)
{
    return self->__instance.ft->ClearElementAt(
        (MI_Instance*)&self->__instance,
        10);
}

MI_INLINE MI_Result MI_CALL MSFT_FileBrowser_Set_LinkCount(
    MSFT_FileBrowser* self,
    MI_Uint64 x)
{
    ((MI_Uint64Field*)&self->LinkCount)->value = x;
    ((MI_Uint64Field*)&self->LinkCount)->exists = 1;
    return MI_RESULT_OK;
}

MI_INLINE MI_Result MI_CALL MSFT_FileBrowser_Clear_LinkCount(
    MSFT_FileBrowser* self)
{
    memset((void*)&self->LinkCount, 0, sizeof(self->LinkCount));
    return MI_RESULT_OK;
}

MI_INLINE MI_Result MI_CALL MSFT_FileBrowser_Set_Size(
    MSFT_FileBrowser* self,
    MI_Uint64 x)
{
    ((MI_Uint64Field*)&self->Size)->value = x;
    ((MI_Uint64Field*)&self->Size)->exists = 1;
    return MI_RESULT_OK;
}

MI_INLINE MI_Result MI_CALL MSFT_FileBrowser_Clear_Size(
    MSFT_FileBrowser* self)
{
    memset((void*)&self->Size, 0, sizeof(self->Size));
    return MI_RESULT_OK;
}

MI_INLINE MI_Result MI_CALL MSFT_FileBrowser_Set_BlockSize(
    MSFT_FileBrowser* self,
    MI_Uint64 x)
{
    ((MI_Uint64Field*)&self->BlockSize)->value = x;
    ((MI_Uint64Field*)&self->BlockSize)->exists = 1;
    return MI_RESULT_OK;
}

MI_INLINE MI_Result MI_CALL MSFT_FileBrowser_Clear_BlockSize(
    MSFT_FileBrowser* self)
{
    memset((void*)&self->BlockSize, 0, sizeof(self->BlockSize));
    return MI_RESULT_OK;
}

MI_INLINE MI_Result MI_CALL MSFT_FileBrowser_Set_BlockCount(
    MSFT_FileBrowser* self,
    MI_Uint64 x)
{
    ((MI_Uint64Field*)&self->BlockCount)->value = x;
    ((MI_Uint64Field*)&self->BlockCount)->exists = 1;
    return MI_RESULT_OK;
}

MI_INLINE MI_Result MI_CALL MSFT_FileBrowser_Clear_BlockCount(
    MSFT_FileBrowser* self)
{
    memset((void*)&self->BlockCount, 0, sizeof(self->BlockCount));
    return MI_RESULT_OK;
}

MI_INLINE MI_Result MI_CALL MSFT_FileBrowser_Set_UserID(
    MSFT_FileBrowser* self,
    MI_Uint32 x)
{
    ((MI_Uint32Field*)&self->UserID)->value = x;
    ((MI_Uint32Field*)&self->UserID)->exists = 1;
    return MI_RESULT_OK;
}

MI_INLINE MI_Result MI_CALL MSFT_FileBrowser_Clear_UserID(
    MSFT_FileBrowser* self)
{
    memset((void*)&self->UserID, 0, sizeof(self->UserID));
    return MI_RESULT_OK;
}

MI_INLINE MI_Result MI_CALL MSFT_FileBrowser_Set_GroupID(
    MSFT_FileBrowser* self,
    MI_Uint32 x)
{
    ((MI_Uint32Field*)&self->GroupID)->value = x;
    ((MI_Uint32Field*)&self->GroupID)->exists = 1;
    return MI_RESULT_OK;
}

MI_INLINE MI_Result MI_CALL MSFT_FileBrowser_Clear_GroupID(
    MSFT_FileBrowser* self)
{
    memset((void*)&self->GroupID, 0, sizeof(self->GroupID));
    return MI_RESULT_OK;
}

MI_INLINE MI_Result MI_CALL MSFT_FileBrowser_Set_Device(
    MSFT_FileBrowser* self,
    MI_Uint64 x)
{
    ((MI_Uint64Field*)&self->Device)->value = x;
    ((MI_Uint64Field*)&self->Device)->exists = 1;
    return MI_RESULT_OK;
}

MI_INLINE MI_Result MI_CALL MSFT_FileBrowser_Clear_Device(
    MSFT_FileBrowser* self)
{
    memset((void*)&self->Device, 0, sizeof(self->Device));
    return MI_RESULT_OK;
}

MI_INLINE MI_Result MI_CALL MSFT_FileBrowser_Set_DeviceNumber(
    MSFT_FileBrowser* self,
    MI_Uint64 x)
{
    ((MI_Uint64Field*)&self->DeviceNumber)->value = x;
    ((MI_Uint64Field*)&self->DeviceNumber)->exists = 1;
    return MI_RESULT_OK;
}

MI_INLINE MI_Result MI_CALL MSFT_FileBrowser_Clear_DeviceNumber(
    MSFT_FileBrowser* self)
{
    memset((void*)&self->DeviceNumber, 0, sizeof(self->DeviceNumber));
    return MI_RESULT_OK;
}

MI_INLINE MI_Result MI_CALL MSFT_FileBrowser_Set_SerialNumber(
    MSFT_FileBrowser* self,
    MI_Uint64 x)
{
    ((MI_Uint64Field*)&self->SerialNumber)->value = x;
    ((MI_Uint64Field*)&self->SerialNumber)->exists = 1;
    return MI_RESULT_OK;
}

MI_INLINE MI_Result MI_CALL MSFT_FileBrowser_Clear_SerialNumber(
    MSFT_FileBrowser* self)
{
    memset((void*)&self->SerialNumber, 0, sizeof(self->SerialNumber));
    return MI_RESULT_OK;
}

MI_INLINE MI_Result MI_CALL MSFT_FileBrowser_Set_ChunkIndex(
    MSFT_FileBrowser* self,
    MI_Uint64 x)
{
    ((MI_Uint64Field*)&self->ChunkIndex)->value = x;
    ((MI_Uint64Field*)&self->ChunkIndex)->exists = 1;
    return MI_RESULT_OK;
}

MI_INLINE MI_Result MI_CALL MSFT_FileBrowser_Clear_ChunkIndex(
    MSFT_FileBrowser* self)
{
    memset((void*)&self->ChunkIndex, 0, sizeof(self->ChunkIndex));
    return MI_RESULT_OK;
}

MI_INLINE MI_Result MI_CALL MSFT_FileBrowser_Set_TotalChunks(
    MSFT_FileBrowser* self,
    MI_Uint64 x)
{
    ((MI_Uint64Field*)&self->TotalChunks)->value = x;
    ((MI_Uint64Field*)&self->TotalChunks)->exists = 1;
    return MI_RESULT_OK;
}

MI_INLINE MI_Result MI_CALL MSFT_FileBrowser_Clear_TotalChunks(
    MSFT_FileBrowser* self)
{
    memset((void*)&self->TotalChunks, 0, sizeof(self->TotalChunks));
    return MI_RESULT_OK;
}

MI_INLINE MI_Result MI_CALL MSFT_FileBrowser_Set_ChunkBytes(
    MSFT_FileBrowser* self,
    MI_Uint64 x)
{
    ((MI_Uint64Field*)&self->ChunkBytes)->value = x;
    ((MI_Uint64Field*)&self->ChunkBytes)->exists = 1;
    return MI_RESULT_OK;
}

MI_INLINE MI_Result MI_CALL MSFT_FileBrowser_Clear_ChunkBytes(
    MSFT_FileBrowser* self)
{
    memset((void*)&self->ChunkBytes, 0, sizeof(self->ChunkBytes));
    return MI_RESULT_OK;
}

MI_INLINE MI_Result MI_CALL MSFT_FileBrowser_Set_OffsetBytes(
    MSFT_FileBrowser* self,
    MI_Uint64 x)
{
    ((MI_Uint64Field*)&self->OffsetBytes)->value = x;
    ((MI_Uint64Field*)&self->OffsetBytes)->exists = 1;
    return MI_RESULT_OK;
}

MI_INLINE MI_Result MI_CALL MSFT_FileBrowser_Clear_OffsetBytes(
    MSFT_FileBrowser* self)
{
    memset((void*)&self->OffsetBytes, 0, sizeof(self->OffsetBytes));
    return MI_RESULT_OK;
}

MI_INLINE MI_Result MI_CALL MSFT_FileBrowser_Set_TotalBytes(
    MSFT_FileBrowser* self,
    MI_Uint64 x)
{
    ((MI_Uint64Field*)&self->TotalBytes)->value = x;
    ((MI_Uint64Field*)&self->TotalBytes)->exists = 1;
    return MI_RESULT_OK;
}

MI_INLINE MI_Result MI_CALL MSFT_FileBrowser_Clear_TotalBytes(
    MSFT_FileBrowser* self)
{
    memset((void*)&self->TotalBytes, 0, sizeof(self->TotalBytes));
    return MI_RESULT_OK;
}

MI_INLINE MI_Result MI_CALL MSFT_FileBrowser_Set_Data(
    MSFT_FileBrowser* self,
    const MI_Char* str)
{
    return self->__instance.ft->SetElementAt(
        (MI_Instance*)&self->__instance,
        25,
        (MI_Value*)&str,
        MI_STRING,
        0);
}

MI_INLINE MI_Result MI_CALL MSFT_FileBrowser_SetPtr_Data(
    MSFT_FileBrowser* self,
    const MI_Char* str)
{
    return self->__instance.ft->SetElementAt(
        (MI_Instance*)&self->__instance,
        25,
        (MI_Value*)&str,
        MI_STRING,
        MI_FLAG_BORROW);
}

MI_INLINE MI_Result MI_CALL MSFT_FileBrowser_Clear_Data(
    MSFT_FileBrowser* self)
{
    return self->__instance.ft->ClearElementAt(
        (MI_Instance*)&self->__instance,
        25);
}

/*
**==============================================================================
**
** MSFT_FileBrowser provider function prototypes
**
**==============================================================================
*/

/* The developer may optionally define this structure */
typedef struct _MSFT_FileBrowser_Self MSFT_FileBrowser_Self;

MI_EXTERN_C void MI_CALL MSFT_FileBrowser_Load(
    MSFT_FileBrowser_Self** self,
    MI_Module_Self* selfModule,
    MI_Context* context);

MI_EXTERN_C void MI_CALL MSFT_FileBrowser_Unload(
    MSFT_FileBrowser_Self* self,
    MI_Context* context);

MI_EXTERN_C void MI_CALL MSFT_FileBrowser_EnumerateInstances(
    MSFT_FileBrowser_Self* self,
    MI_Context* context,
    const MI_Char* nameSpace,
    const MI_Char* className,
    const MI_PropertySet* propertySet,
    MI_Boolean keysOnly,
    const MI_Filter* filter);

MI_EXTERN_C void MI_CALL MSFT_FileBrowser_GetInstance(
    MSFT_FileBrowser_Self* self,
    MI_Context* context,
    const MI_Char* nameSpace,
    const MI_Char* className,
    const MSFT_FileBrowser* instanceName,
    const MI_PropertySet* propertySet);

MI_EXTERN_C void MI_CALL MSFT_FileBrowser_CreateInstance(
    MSFT_FileBrowser_Self* self,
    MI_Context* context,
    const MI_Char* nameSpace,
    const MI_Char* className,
    const MSFT_FileBrowser* newInstance);

MI_EXTERN_C void MI_CALL MSFT_FileBrowser_ModifyInstance(
    MSFT_FileBrowser_Self* self,
    MI_Context* context,
    const MI_Char* nameSpace,
    const MI_Char* className,
    const MSFT_FileBrowser* modifiedInstance,
    const MI_PropertySet* propertySet);

MI_EXTERN_C void MI_CALL MSFT_FileBrowser_DeleteInstance(
    MSFT_FileBrowser_Self* self,
    MI_Context* context,
    const MI_Char* nameSpace,
    const MI_Char* className,
    const MSFT_FileBrowser* instanceName);


/*
**==============================================================================
**
** MSFT_FileBrowser_Class
**
**==============================================================================
*/

#ifdef __cplusplus
# include <micxx/micxx.h>

MI_BEGIN_NAMESPACE

class MSFT_FileBrowser_Class : public Instance
{
public:
    
    typedef MSFT_FileBrowser Self;
    
    MSFT_FileBrowser_Class() :
        Instance(&MSFT_FileBrowser_rtti)
    {
    }
    
    MSFT_FileBrowser_Class(
        const MSFT_FileBrowser* instanceName,
        bool keysOnly) :
        Instance(
            &MSFT_FileBrowser_rtti,
            &instanceName->__instance,
            keysOnly)
    {
    }
    
    MSFT_FileBrowser_Class(
        const MI_ClassDecl* clDecl,
        const MI_Instance* instance,
        bool keysOnly) :
        Instance(clDecl, instance, keysOnly)
    {
    }
    
    MSFT_FileBrowser_Class(
        const MI_ClassDecl* clDecl) :
        Instance(clDecl)
    {
    }
    
    MSFT_FileBrowser_Class& operator=(
        const MSFT_FileBrowser_Class& x)
    {
        CopyRef(x);
        return *this;
    }
    
    MSFT_FileBrowser_Class(
        const MSFT_FileBrowser_Class& x) :
        Instance(x)
    {
    }

    static const MI_ClassDecl* GetClassDecl()
    {
        return &MSFT_FileBrowser_rtti;
    }

    //
    // MSFT_FileBrowser_Class.TargetPath
    //
    
    const Field<String>& TargetPath() const
    {
        const size_t n = offsetof(Self, TargetPath);
        return GetField<String>(n);
    }
    
    void TargetPath(const Field<String>& x)
    {
        const size_t n = offsetof(Self, TargetPath);
        GetField<String>(n) = x;
    }
    
    const String& TargetPath_value() const
    {
        const size_t n = offsetof(Self, TargetPath);
        return GetField<String>(n).value;
    }
    
    void TargetPath_value(const String& x)
    {
        const size_t n = offsetof(Self, TargetPath);
        GetField<String>(n).Set(x);
    }
    
    bool TargetPath_exists() const
    {
        const size_t n = offsetof(Self, TargetPath);
        return GetField<String>(n).exists ? true : false;
    }
    
    void TargetPath_clear()
    {
        const size_t n = offsetof(Self, TargetPath);
        GetField<String>(n).Clear();
    }

    //
    // MSFT_FileBrowser_Class.Function
    //
    
    const Field<String>& Function() const
    {
        const size_t n = offsetof(Self, Function);
        return GetField<String>(n);
    }
    
    void Function(const Field<String>& x)
    {
        const size_t n = offsetof(Self, Function);
        GetField<String>(n) = x;
    }
    
    const String& Function_value() const
    {
        const size_t n = offsetof(Self, Function);
        return GetField<String>(n).value;
    }
    
    void Function_value(const String& x)
    {
        const size_t n = offsetof(Self, Function);
        GetField<String>(n).Set(x);
    }
    
    bool Function_exists() const
    {
        const size_t n = offsetof(Self, Function);
        return GetField<String>(n).exists ? true : false;
    }
    
    void Function_clear()
    {
        const size_t n = offsetof(Self, Function);
        GetField<String>(n).Clear();
    }

    //
    // MSFT_FileBrowser_Class.FullPath
    //
    
    const Field<String>& FullPath() const
    {
        const size_t n = offsetof(Self, FullPath);
        return GetField<String>(n);
    }
    
    void FullPath(const Field<String>& x)
    {
        const size_t n = offsetof(Self, FullPath);
        GetField<String>(n) = x;
    }
    
    const String& FullPath_value() const
    {
        const size_t n = offsetof(Self, FullPath);
        return GetField<String>(n).value;
    }
    
    void FullPath_value(const String& x)
    {
        const size_t n = offsetof(Self, FullPath);
        GetField<String>(n).Set(x);
    }
    
    bool FullPath_exists() const
    {
        const size_t n = offsetof(Self, FullPath);
        return GetField<String>(n).exists ? true : false;
    }
    
    void FullPath_clear()
    {
        const size_t n = offsetof(Self, FullPath);
        GetField<String>(n).Clear();
    }

    //
    // MSFT_FileBrowser_Class.Name
    //
    
    const Field<String>& Name() const
    {
        const size_t n = offsetof(Self, Name);
        return GetField<String>(n);
    }
    
    void Name(const Field<String>& x)
    {
        const size_t n = offsetof(Self, Name);
        GetField<String>(n) = x;
    }
    
    const String& Name_value() const
    {
        const size_t n = offsetof(Self, Name);
        return GetField<String>(n).value;
    }
    
    void Name_value(const String& x)
    {
        const size_t n = offsetof(Self, Name);
        GetField<String>(n).Set(x);
    }
    
    bool Name_exists() const
    {
        const size_t n = offsetof(Self, Name);
        return GetField<String>(n).exists ? true : false;
    }
    
    void Name_clear()
    {
        const size_t n = offsetof(Self, Name);
        GetField<String>(n).Clear();
    }

    //
    // MSFT_FileBrowser_Class.FolderSeparator
    //
    
    const Field<String>& FolderSeparator() const
    {
        const size_t n = offsetof(Self, FolderSeparator);
        return GetField<String>(n);
    }
    
    void FolderSeparator(const Field<String>& x)
    {
        const size_t n = offsetof(Self, FolderSeparator);
        GetField<String>(n) = x;
    }
    
    const String& FolderSeparator_value() const
    {
        const size_t n = offsetof(Self, FolderSeparator);
        return GetField<String>(n).value;
    }
    
    void FolderSeparator_value(const String& x)
    {
        const size_t n = offsetof(Self, FolderSeparator);
        GetField<String>(n).Set(x);
    }
    
    bool FolderSeparator_exists() const
    {
        const size_t n = offsetof(Self, FolderSeparator);
        return GetField<String>(n).exists ? true : false;
    }
    
    void FolderSeparator_clear()
    {
        const size_t n = offsetof(Self, FolderSeparator);
        GetField<String>(n).Clear();
    }

    //
    // MSFT_FileBrowser_Class.PathExists
    //
    
    const Field<Boolean>& PathExists() const
    {
        const size_t n = offsetof(Self, PathExists);
        return GetField<Boolean>(n);
    }
    
    void PathExists(const Field<Boolean>& x)
    {
        const size_t n = offsetof(Self, PathExists);
        GetField<Boolean>(n) = x;
    }
    
    const Boolean& PathExists_value() const
    {
        const size_t n = offsetof(Self, PathExists);
        return GetField<Boolean>(n).value;
    }
    
    void PathExists_value(const Boolean& x)
    {
        const size_t n = offsetof(Self, PathExists);
        GetField<Boolean>(n).Set(x);
    }
    
    bool PathExists_exists() const
    {
        const size_t n = offsetof(Self, PathExists);
        return GetField<Boolean>(n).exists ? true : false;
    }
    
    void PathExists_clear()
    {
        const size_t n = offsetof(Self, PathExists);
        GetField<Boolean>(n).Clear();
    }

    //
    // MSFT_FileBrowser_Class.AccessRights
    //
    
    const Field<String>& AccessRights() const
    {
        const size_t n = offsetof(Self, AccessRights);
        return GetField<String>(n);
    }
    
    void AccessRights(const Field<String>& x)
    {
        const size_t n = offsetof(Self, AccessRights);
        GetField<String>(n) = x;
    }
    
    const String& AccessRights_value() const
    {
        const size_t n = offsetof(Self, AccessRights);
        return GetField<String>(n).value;
    }
    
    void AccessRights_value(const String& x)
    {
        const size_t n = offsetof(Self, AccessRights);
        GetField<String>(n).Set(x);
    }
    
    bool AccessRights_exists() const
    {
        const size_t n = offsetof(Self, AccessRights);
        return GetField<String>(n).exists ? true : false;
    }
    
    void AccessRights_clear()
    {
        const size_t n = offsetof(Self, AccessRights);
        GetField<String>(n).Clear();
    }

    //
    // MSFT_FileBrowser_Class.Directory
    //
    
    const Field<Boolean>& Directory() const
    {
        const size_t n = offsetof(Self, Directory);
        return GetField<Boolean>(n);
    }
    
    void Directory(const Field<Boolean>& x)
    {
        const size_t n = offsetof(Self, Directory);
        GetField<Boolean>(n) = x;
    }
    
    const Boolean& Directory_value() const
    {
        const size_t n = offsetof(Self, Directory);
        return GetField<Boolean>(n).value;
    }
    
    void Directory_value(const Boolean& x)
    {
        const size_t n = offsetof(Self, Directory);
        GetField<Boolean>(n).Set(x);
    }
    
    bool Directory_exists() const
    {
        const size_t n = offsetof(Self, Directory);
        return GetField<Boolean>(n).exists ? true : false;
    }
    
    void Directory_clear()
    {
        const size_t n = offsetof(Self, Directory);
        GetField<Boolean>(n).Clear();
    }

    //
    // MSFT_FileBrowser_Class.LastAccessTimeUTC
    //
    
    const Field<String>& LastAccessTimeUTC() const
    {
        const size_t n = offsetof(Self, LastAccessTimeUTC);
        return GetField<String>(n);
    }
    
    void LastAccessTimeUTC(const Field<String>& x)
    {
        const size_t n = offsetof(Self, LastAccessTimeUTC);
        GetField<String>(n) = x;
    }
    
    const String& LastAccessTimeUTC_value() const
    {
        const size_t n = offsetof(Self, LastAccessTimeUTC);
        return GetField<String>(n).value;
    }
    
    void LastAccessTimeUTC_value(const String& x)
    {
        const size_t n = offsetof(Self, LastAccessTimeUTC);
        GetField<String>(n).Set(x);
    }
    
    bool LastAccessTimeUTC_exists() const
    {
        const size_t n = offsetof(Self, LastAccessTimeUTC);
        return GetField<String>(n).exists ? true : false;
    }
    
    void LastAccessTimeUTC_clear()
    {
        const size_t n = offsetof(Self, LastAccessTimeUTC);
        GetField<String>(n).Clear();
    }

    //
    // MSFT_FileBrowser_Class.LastModificationTimeUTC
    //
    
    const Field<String>& LastModificationTimeUTC() const
    {
        const size_t n = offsetof(Self, LastModificationTimeUTC);
        return GetField<String>(n);
    }
    
    void LastModificationTimeUTC(const Field<String>& x)
    {
        const size_t n = offsetof(Self, LastModificationTimeUTC);
        GetField<String>(n) = x;
    }
    
    const String& LastModificationTimeUTC_value() const
    {
        const size_t n = offsetof(Self, LastModificationTimeUTC);
        return GetField<String>(n).value;
    }
    
    void LastModificationTimeUTC_value(const String& x)
    {
        const size_t n = offsetof(Self, LastModificationTimeUTC);
        GetField<String>(n).Set(x);
    }
    
    bool LastModificationTimeUTC_exists() const
    {
        const size_t n = offsetof(Self, LastModificationTimeUTC);
        return GetField<String>(n).exists ? true : false;
    }
    
    void LastModificationTimeUTC_clear()
    {
        const size_t n = offsetof(Self, LastModificationTimeUTC);
        GetField<String>(n).Clear();
    }

    //
    // MSFT_FileBrowser_Class.LastStatusChangeTimeUTC
    //
    
    const Field<String>& LastStatusChangeTimeUTC() const
    {
        const size_t n = offsetof(Self, LastStatusChangeTimeUTC);
        return GetField<String>(n);
    }
    
    void LastStatusChangeTimeUTC(const Field<String>& x)
    {
        const size_t n = offsetof(Self, LastStatusChangeTimeUTC);
        GetField<String>(n) = x;
    }
    
    const String& LastStatusChangeTimeUTC_value() const
    {
        const size_t n = offsetof(Self, LastStatusChangeTimeUTC);
        return GetField<String>(n).value;
    }
    
    void LastStatusChangeTimeUTC_value(const String& x)
    {
        const size_t n = offsetof(Self, LastStatusChangeTimeUTC);
        GetField<String>(n).Set(x);
    }
    
    bool LastStatusChangeTimeUTC_exists() const
    {
        const size_t n = offsetof(Self, LastStatusChangeTimeUTC);
        return GetField<String>(n).exists ? true : false;
    }
    
    void LastStatusChangeTimeUTC_clear()
    {
        const size_t n = offsetof(Self, LastStatusChangeTimeUTC);
        GetField<String>(n).Clear();
    }

    //
    // MSFT_FileBrowser_Class.LinkCount
    //
    
    const Field<Uint64>& LinkCount() const
    {
        const size_t n = offsetof(Self, LinkCount);
        return GetField<Uint64>(n);
    }
    
    void LinkCount(const Field<Uint64>& x)
    {
        const size_t n = offsetof(Self, LinkCount);
        GetField<Uint64>(n) = x;
    }
    
    const Uint64& LinkCount_value() const
    {
        const size_t n = offsetof(Self, LinkCount);
        return GetField<Uint64>(n).value;
    }
    
    void LinkCount_value(const Uint64& x)
    {
        const size_t n = offsetof(Self, LinkCount);
        GetField<Uint64>(n).Set(x);
    }
    
    bool LinkCount_exists() const
    {
        const size_t n = offsetof(Self, LinkCount);
        return GetField<Uint64>(n).exists ? true : false;
    }
    
    void LinkCount_clear()
    {
        const size_t n = offsetof(Self, LinkCount);
        GetField<Uint64>(n).Clear();
    }

    //
    // MSFT_FileBrowser_Class.Size
    //
    
    const Field<Uint64>& Size() const
    {
        const size_t n = offsetof(Self, Size);
        return GetField<Uint64>(n);
    }
    
    void Size(const Field<Uint64>& x)
    {
        const size_t n = offsetof(Self, Size);
        GetField<Uint64>(n) = x;
    }
    
    const Uint64& Size_value() const
    {
        const size_t n = offsetof(Self, Size);
        return GetField<Uint64>(n).value;
    }
    
    void Size_value(const Uint64& x)
    {
        const size_t n = offsetof(Self, Size);
        GetField<Uint64>(n).Set(x);
    }
    
    bool Size_exists() const
    {
        const size_t n = offsetof(Self, Size);
        return GetField<Uint64>(n).exists ? true : false;
    }
    
    void Size_clear()
    {
        const size_t n = offsetof(Self, Size);
        GetField<Uint64>(n).Clear();
    }

    //
    // MSFT_FileBrowser_Class.BlockSize
    //
    
    const Field<Uint64>& BlockSize() const
    {
        const size_t n = offsetof(Self, BlockSize);
        return GetField<Uint64>(n);
    }
    
    void BlockSize(const Field<Uint64>& x)
    {
        const size_t n = offsetof(Self, BlockSize);
        GetField<Uint64>(n) = x;
    }
    
    const Uint64& BlockSize_value() const
    {
        const size_t n = offsetof(Self, BlockSize);
        return GetField<Uint64>(n).value;
    }
    
    void BlockSize_value(const Uint64& x)
    {
        const size_t n = offsetof(Self, BlockSize);
        GetField<Uint64>(n).Set(x);
    }
    
    bool BlockSize_exists() const
    {
        const size_t n = offsetof(Self, BlockSize);
        return GetField<Uint64>(n).exists ? true : false;
    }
    
    void BlockSize_clear()
    {
        const size_t n = offsetof(Self, BlockSize);
        GetField<Uint64>(n).Clear();
    }

    //
    // MSFT_FileBrowser_Class.BlockCount
    //
    
    const Field<Uint64>& BlockCount() const
    {
        const size_t n = offsetof(Self, BlockCount);
        return GetField<Uint64>(n);
    }
    
    void BlockCount(const Field<Uint64>& x)
    {
        const size_t n = offsetof(Self, BlockCount);
        GetField<Uint64>(n) = x;
    }
    
    const Uint64& BlockCount_value() const
    {
        const size_t n = offsetof(Self, BlockCount);
        return GetField<Uint64>(n).value;
    }
    
    void BlockCount_value(const Uint64& x)
    {
        const size_t n = offsetof(Self, BlockCount);
        GetField<Uint64>(n).Set(x);
    }
    
    bool BlockCount_exists() const
    {
        const size_t n = offsetof(Self, BlockCount);
        return GetField<Uint64>(n).exists ? true : false;
    }
    
    void BlockCount_clear()
    {
        const size_t n = offsetof(Self, BlockCount);
        GetField<Uint64>(n).Clear();
    }

    //
    // MSFT_FileBrowser_Class.UserID
    //
    
    const Field<Uint32>& UserID() const
    {
        const size_t n = offsetof(Self, UserID);
        return GetField<Uint32>(n);
    }
    
    void UserID(const Field<Uint32>& x)
    {
        const size_t n = offsetof(Self, UserID);
        GetField<Uint32>(n) = x;
    }
    
    const Uint32& UserID_value() const
    {
        const size_t n = offsetof(Self, UserID);
        return GetField<Uint32>(n).value;
    }
    
    void UserID_value(const Uint32& x)
    {
        const size_t n = offsetof(Self, UserID);
        GetField<Uint32>(n).Set(x);
    }
    
    bool UserID_exists() const
    {
        const size_t n = offsetof(Self, UserID);
        return GetField<Uint32>(n).exists ? true : false;
    }
    
    void UserID_clear()
    {
        const size_t n = offsetof(Self, UserID);
        GetField<Uint32>(n).Clear();
    }

    //
    // MSFT_FileBrowser_Class.GroupID
    //
    
    const Field<Uint32>& GroupID() const
    {
        const size_t n = offsetof(Self, GroupID);
        return GetField<Uint32>(n);
    }
    
    void GroupID(const Field<Uint32>& x)
    {
        const size_t n = offsetof(Self, GroupID);
        GetField<Uint32>(n) = x;
    }
    
    const Uint32& GroupID_value() const
    {
        const size_t n = offsetof(Self, GroupID);
        return GetField<Uint32>(n).value;
    }
    
    void GroupID_value(const Uint32& x)
    {
        const size_t n = offsetof(Self, GroupID);
        GetField<Uint32>(n).Set(x);
    }
    
    bool GroupID_exists() const
    {
        const size_t n = offsetof(Self, GroupID);
        return GetField<Uint32>(n).exists ? true : false;
    }
    
    void GroupID_clear()
    {
        const size_t n = offsetof(Self, GroupID);
        GetField<Uint32>(n).Clear();
    }

    //
    // MSFT_FileBrowser_Class.Device
    //
    
    const Field<Uint64>& Device() const
    {
        const size_t n = offsetof(Self, Device);
        return GetField<Uint64>(n);
    }
    
    void Device(const Field<Uint64>& x)
    {
        const size_t n = offsetof(Self, Device);
        GetField<Uint64>(n) = x;
    }
    
    const Uint64& Device_value() const
    {
        const size_t n = offsetof(Self, Device);
        return GetField<Uint64>(n).value;
    }
    
    void Device_value(const Uint64& x)
    {
        const size_t n = offsetof(Self, Device);
        GetField<Uint64>(n).Set(x);
    }
    
    bool Device_exists() const
    {
        const size_t n = offsetof(Self, Device);
        return GetField<Uint64>(n).exists ? true : false;
    }
    
    void Device_clear()
    {
        const size_t n = offsetof(Self, Device);
        GetField<Uint64>(n).Clear();
    }

    //
    // MSFT_FileBrowser_Class.DeviceNumber
    //
    
    const Field<Uint64>& DeviceNumber() const
    {
        const size_t n = offsetof(Self, DeviceNumber);
        return GetField<Uint64>(n);
    }
    
    void DeviceNumber(const Field<Uint64>& x)
    {
        const size_t n = offsetof(Self, DeviceNumber);
        GetField<Uint64>(n) = x;
    }
    
    const Uint64& DeviceNumber_value() const
    {
        const size_t n = offsetof(Self, DeviceNumber);
        return GetField<Uint64>(n).value;
    }
    
    void DeviceNumber_value(const Uint64& x)
    {
        const size_t n = offsetof(Self, DeviceNumber);
        GetField<Uint64>(n).Set(x);
    }
    
    bool DeviceNumber_exists() const
    {
        const size_t n = offsetof(Self, DeviceNumber);
        return GetField<Uint64>(n).exists ? true : false;
    }
    
    void DeviceNumber_clear()
    {
        const size_t n = offsetof(Self, DeviceNumber);
        GetField<Uint64>(n).Clear();
    }

    //
    // MSFT_FileBrowser_Class.SerialNumber
    //
    
    const Field<Uint64>& SerialNumber() const
    {
        const size_t n = offsetof(Self, SerialNumber);
        return GetField<Uint64>(n);
    }
    
    void SerialNumber(const Field<Uint64>& x)
    {
        const size_t n = offsetof(Self, SerialNumber);
        GetField<Uint64>(n) = x;
    }
    
    const Uint64& SerialNumber_value() const
    {
        const size_t n = offsetof(Self, SerialNumber);
        return GetField<Uint64>(n).value;
    }
    
    void SerialNumber_value(const Uint64& x)
    {
        const size_t n = offsetof(Self, SerialNumber);
        GetField<Uint64>(n).Set(x);
    }
    
    bool SerialNumber_exists() const
    {
        const size_t n = offsetof(Self, SerialNumber);
        return GetField<Uint64>(n).exists ? true : false;
    }
    
    void SerialNumber_clear()
    {
        const size_t n = offsetof(Self, SerialNumber);
        GetField<Uint64>(n).Clear();
    }

    //
    // MSFT_FileBrowser_Class.ChunkIndex
    //
    
    const Field<Uint64>& ChunkIndex() const
    {
        const size_t n = offsetof(Self, ChunkIndex);
        return GetField<Uint64>(n);
    }
    
    void ChunkIndex(const Field<Uint64>& x)
    {
        const size_t n = offsetof(Self, ChunkIndex);
        GetField<Uint64>(n) = x;
    }
    
    const Uint64& ChunkIndex_value() const
    {
        const size_t n = offsetof(Self, ChunkIndex);
        return GetField<Uint64>(n).value;
    }
    
    void ChunkIndex_value(const Uint64& x)
    {
        const size_t n = offsetof(Self, ChunkIndex);
        GetField<Uint64>(n).Set(x);
    }
    
    bool ChunkIndex_exists() const
    {
        const size_t n = offsetof(Self, ChunkIndex);
        return GetField<Uint64>(n).exists ? true : false;
    }
    
    void ChunkIndex_clear()
    {
        const size_t n = offsetof(Self, ChunkIndex);
        GetField<Uint64>(n).Clear();
    }

    //
    // MSFT_FileBrowser_Class.TotalChunks
    //
    
    const Field<Uint64>& TotalChunks() const
    {
        const size_t n = offsetof(Self, TotalChunks);
        return GetField<Uint64>(n);
    }
    
    void TotalChunks(const Field<Uint64>& x)
    {
        const size_t n = offsetof(Self, TotalChunks);
        GetField<Uint64>(n) = x;
    }
    
    const Uint64& TotalChunks_value() const
    {
        const size_t n = offsetof(Self, TotalChunks);
        return GetField<Uint64>(n).value;
    }
    
    void TotalChunks_value(const Uint64& x)
    {
        const size_t n = offsetof(Self, TotalChunks);
        GetField<Uint64>(n).Set(x);
    }
    
    bool TotalChunks_exists() const
    {
        const size_t n = offsetof(Self, TotalChunks);
        return GetField<Uint64>(n).exists ? true : false;
    }
    
    void TotalChunks_clear()
    {
        const size_t n = offsetof(Self, TotalChunks);
        GetField<Uint64>(n).Clear();
    }

    //
    // MSFT_FileBrowser_Class.ChunkBytes
    //
    
    const Field<Uint64>& ChunkBytes() const
    {
        const size_t n = offsetof(Self, ChunkBytes);
        return GetField<Uint64>(n);
    }
    
    void ChunkBytes(const Field<Uint64>& x)
    {
        const size_t n = offsetof(Self, ChunkBytes);
        GetField<Uint64>(n) = x;
    }
    
    const Uint64& ChunkBytes_value() const
    {
        const size_t n = offsetof(Self, ChunkBytes);
        return GetField<Uint64>(n).value;
    }
    
    void ChunkBytes_value(const Uint64& x)
    {
        const size_t n = offsetof(Self, ChunkBytes);
        GetField<Uint64>(n).Set(x);
    }
    
    bool ChunkBytes_exists() const
    {
        const size_t n = offsetof(Self, ChunkBytes);
        return GetField<Uint64>(n).exists ? true : false;
    }
    
    void ChunkBytes_clear()
    {
        const size_t n = offsetof(Self, ChunkBytes);
        GetField<Uint64>(n).Clear();
    }

    //
    // MSFT_FileBrowser_Class.OffsetBytes
    //
    
    const Field<Uint64>& OffsetBytes() const
    {
        const size_t n = offsetof(Self, OffsetBytes);
        return GetField<Uint64>(n);
    }
    
    void OffsetBytes(const Field<Uint64>& x)
    {
        const size_t n = offsetof(Self, OffsetBytes);
        GetField<Uint64>(n) = x;
    }
    
    const Uint64& OffsetBytes_value() const
    {
        const size_t n = offsetof(Self, OffsetBytes);
        return GetField<Uint64>(n).value;
    }
    
    void OffsetBytes_value(const Uint64& x)
    {
        const size_t n = offsetof(Self, OffsetBytes);
        GetField<Uint64>(n).Set(x);
    }
    
    bool OffsetBytes_exists() const
    {
        const size_t n = offsetof(Self, OffsetBytes);
        return GetField<Uint64>(n).exists ? true : false;
    }
    
    void OffsetBytes_clear()
    {
        const size_t n = offsetof(Self, OffsetBytes);
        GetField<Uint64>(n).Clear();
    }

    //
    // MSFT_FileBrowser_Class.TotalBytes
    //
    
    const Field<Uint64>& TotalBytes() const
    {
        const size_t n = offsetof(Self, TotalBytes);
        return GetField<Uint64>(n);
    }
    
    void TotalBytes(const Field<Uint64>& x)
    {
        const size_t n = offsetof(Self, TotalBytes);
        GetField<Uint64>(n) = x;
    }
    
    const Uint64& TotalBytes_value() const
    {
        const size_t n = offsetof(Self, TotalBytes);
        return GetField<Uint64>(n).value;
    }
    
    void TotalBytes_value(const Uint64& x)
    {
        const size_t n = offsetof(Self, TotalBytes);
        GetField<Uint64>(n).Set(x);
    }
    
    bool TotalBytes_exists() const
    {
        const size_t n = offsetof(Self, TotalBytes);
        return GetField<Uint64>(n).exists ? true : false;
    }
    
    void TotalBytes_clear()
    {
        const size_t n = offsetof(Self, TotalBytes);
        GetField<Uint64>(n).Clear();
    }

    //
    // MSFT_FileBrowser_Class.Data
    //
    
    const Field<String>& Data() const
    {
        const size_t n = offsetof(Self, Data);
        return GetField<String>(n);
    }
    
    void Data(const Field<String>& x)
    {
        const size_t n = offsetof(Self, Data);
        GetField<String>(n) = x;
    }
    
    const String& Data_value() const
    {
        const size_t n = offsetof(Self, Data);
        return GetField<String>(n).value;
    }
    
    void Data_value(const String& x)
    {
        const size_t n = offsetof(Self, Data);
        GetField<String>(n).Set(x);
    }
    
    bool Data_exists() const
    {
        const size_t n = offsetof(Self, Data);
        return GetField<String>(n).exists ? true : false;
    }
    
    void Data_clear()
    {
        const size_t n = offsetof(Self, Data);
        GetField<String>(n).Clear();
    }
};

typedef Array<MSFT_FileBrowser_Class> MSFT_FileBrowser_ClassA;

MI_END_NAMESPACE

#endif /* __cplusplus */

#endif /* _MSFT_FileBrowser_h */
