#include <MI.h>
#include "module.h"

MI_BEGIN_NAMESPACE

Module::Module()
{
}

Module::~Module()
{
}

MI_END_NAMESPACE

