/* @migen@ */
#include <MI.h>
#include "MSFT_FileBrowser_Class_Provider.h"

#include <iterator>
#include <stdexcept>
#include <string>
#include <sstream>

#include <scxcorelib/scxcmn.h>
#include <scxcorelib/scxdirectoryinfo.h>
#include <scxcorelib/scxexception.h>
#include <scxcorelib/scxfile.h>
#include <scxcorelib/scxfilesystem.h>
#include <scxcorelib/stringaid.h>
#include <util/Base64Helper.h>

using namespace std;
using namespace SCXCoreLib;

MI_BEGIN_NAMESPACE

// exception thrown if provider cannot continue
class Failure: public SCXException
{
public:
    Failure(const wstring& error, const SCXCodeLocation& location)
        : SCXException(location), m_error(error) {}
    std::wstring What() const
    {
        return L"Provider failed: " + m_error;
    }
private:
    wstring m_error;
};

// exception thrown if given invalid (or missing required) parameter
class InvalidParameter: public SCXException
{
public:
    InvalidParameter(const wstring& error, const SCXCodeLocation& location)
        : SCXException(location), m_error(error) {}
    std::wstring What() const
    {
        return L"Provider failed: " + m_error;
    }
private:
    wstring m_error;
};

// exception thrown if given invalid (or missing required) parameter
class MissingFile: public SCXException
{
public:
    MissingFile(const SCXFilePath& filePath, const SCXCodeLocation& location)
        : SCXException(location), m_filePath(StrFromUTF8(SCXFileSystem::EncodePath(filePath))) {}
    std::wstring What() const
    {
        return L"Provider failed to find file/directory at: " + m_filePath;
    }
private:
    wstring m_filePath;
};

// exception thrown if value cannot be found for the specified key in a given query
class MissingValue: public SCXException
{
public:
    MissingValue(const string& key, const string& query, const SCXCodeLocation& location)
        : SCXException(location), m_key(key), m_query(query) {}
    std::wstring What() const
    {
        return L"Provider failed to find value for key " + StrFromUTF8(m_key) + L", in query " + StrFromUTF8(m_query);
    }
private:
    string m_key;
    string m_query;
};

// helper to get a value for a specified key in a given query, throws MissingValue
string GetValueForKey(const string& key, const string& query)
{
    string delimiter("\"\'");
    string::size_type start(query.find(key)); // start position of key in query
    string::size_type quote(query.find_first_of(delimiter, start)); // position of first quote after key
    // if the key or first quote are not found, abort; otherwise assume all is well
    if (start == string::npos || quote == string::npos)
    {
        throw MissingValue(key, query, SCXSRCLOCATION);
    }
    // these substr's won't throw exceptions as quote and 0 are guaranteed to be in bounds
    string tail(query.substr(quote + 1 /* " */)); // tail of query not including first quote
    string value(tail.substr(0, tail.find_first_of(delimiter))); // value not including second quote
    return value;
}

// helper to enumerate (fill-in) an instance given a file and instance key
MSFT_FileBrowser_Class EnumerateOneInstance(const SCXFileInfo& file, const string& targetPath, const string& function = "")
{
    MSFT_FileBrowser_Class inst;

    // Set all the OMI instance values using the corresponding SCXFileInfo
    // function. OMI strings take char* type. Any wstring (used by the PAL)
    // is converted via the StrToUTF8 helper function from stringaid. The
    // time functions return SCXCalendarTime objects, which have multiple
    // conversion functions built-in; we're using the CIM version for
    // now. The following functions do not throw exceptions.

    // this property must match the query to not be filtered out
    inst.TargetPath_value(targetPath.c_str());

    // function must also match, but GetInstance does not use it
    if (function != "")
    {
        inst.Function_value(function.c_str()); // this property must match the query to not be filtered out
    }

    // get folder separator into wstringstream for easy conversion to UTF8 string then to C string
    wstringstream folderSeparatorStream;
    folderSeparatorStream << SCXFilePath::GetFolderSeparator();
    wstring folderSeparator(folderSeparatorStream.str());

    inst.FullPath_value(SCXFileSystem::EncodePath(file.GetFullPath()).c_str()); // get the PAL resolved path
    {
        // get base name of file/directory without trailing slash
        wstring name(file.GetFullPath().GetFilename()); // works for files
        if (file.IsDirectory())
        {
            wstring wpath(file.GetFullPath().Get());
            if (wpath != folderSeparator) // skip this for root
            {
                if (*wpath.rbegin() == SCXFilePath::GetFolderSeparator())
                {
                    // remove trailing slash
                    wpath.erase(wpath.size() - 1);
                }
                // algorithm to get base name of directory
                name = wpath.substr(wpath.find_last_of(SCXFilePath::GetFolderSeparator()));
            }
            else // preserver root
            {
                name = folderSeparator;
            }
        }
        inst.Name_value(StrToUTF8(name).c_str());
    }

    inst.FolderSeparator_value(StrToUTF8(folderSeparator).c_str());
    inst.PathExists_value(file.Exists());
    inst.AccessRights_value(StrToUTF8(SCXFileSystem::AsText(file.GetAttributes())).c_str());
    inst.Directory_value(file.IsDirectory());
    inst.LastAccessTimeUTC_value(StrToUTF8(file.GetLastAccessTimeUTC().ToExtendedISO8601()).c_str()); // FUTURE: change to Epoch time?
    inst.LastModificationTimeUTC_value(StrToUTF8(file.GetLastModificationTimeUTC().ToExtendedISO8601()).c_str());
    inst.LastStatusChangeTimeUTC_value(StrToUTF8(file.GetLastStatusChangeTimeUTC().ToExtendedISO8601()).c_str());
    inst.LinkCount_value(file.GetLinkCount());
    inst.Size_value(file.GetSize());
    inst.BlockSize_value(file.GetBlockSize());
    inst.BlockCount_value(file.GetBlockCount());
    inst.UserID_value(file.GetUserID()); // FUTURE: resolve to user name?
    inst.GroupID_value(file.GetGroupID());
    inst.Device_value(file.GetDevice());
    inst.DeviceNumber_value(file.GetDeviceNumber());
    inst.SerialNumber_value(file.GetSerialNumber());

    return inst;
}

// validates bytes, throws SCXNotSupportedException if anything is wrong
void validateBytes(size_t fileBytes, size_t chunkBytes, size_t offsetBytes, size_t totalBytes)
{
    if (chunkBytes == 0)
    {
        throw Failure(L"ChunkSize must not be zero", SCXSRCLOCATION);
    }

    // string::value_type *should* be 1 and thus this always true;
    // but the important part is that it evenly divides chunkSize.
    if (chunkBytes % sizeof(string::value_type) != 0)
    {
        throw Failure(L"chunkSize must evenly divide size of string::value_type", SCXSRCLOCATION);
    }

    if (offsetBytes > fileBytes)
    {
        throw Failure(L"OffsetBytes must not be past end of file", SCXSRCLOCATION);
    }

    if (totalBytes > fileBytes - offsetBytes)
    {
        throw Failure(L"TotalBytes must not be past end of file", SCXSRCLOCATION);
    }

    // read uses streamsize which *should* be the same as size_t (i.e. bytes)
    if (sizeof(streamsize) != sizeof(size_t))
    {
        throw Failure(L"streamsize must be the same as size_t", SCXSRCLOCATION);
    }
}

MSFT_FileBrowser_Class_Provider::MSFT_FileBrowser_Class_Provider(
    Module* module) :
    m_Module(module)
{
}

MSFT_FileBrowser_Class_Provider::~MSFT_FileBrowser_Class_Provider()
{
}

void MSFT_FileBrowser_Class_Provider::Load(
    Context& context)
{
    context.Post(MI_RESULT_OK);
}

void MSFT_FileBrowser_Class_Provider::Unload(
    Context& context)
{
    context.Post(MI_RESULT_OK);
}

void MSFT_FileBrowser_Class_Provider::EnumerateInstances(
    Context& context,
    const String& nameSpace,
    const PropertySet& propertySet,
    bool keysOnly,
    const MI_Filter* filter)
{
    try
    {
        // This provider's interface is the WQL invocation, which is a
        // SQL-like query made by the OMI client to the OMI server, which
        // then uses the EnumerateInstances (EI) function and sends to it a
        // filter object, which contains the query. In this way we are able
        // to indirectly send input to EI; however, a direct call to EI is
        // NOT supported, as a filter object (our input) will not be
        // received, and the enumeration cannot be done without input
        // (namely, the TargetPath). As such, if 'filter' is NULL, abort.
        if (!filter)
        {
            throw SCXNotSupportedException(L"EnumerateInstances cannot be called without filter", SCXSRCLOCATION);
        }

        // We receive the input through this MI_Filter pointer, which is a
        // struct defined in MI.h. This struct has one thing: a pointer to a
        // FilterFT struct, which is the function table. This next struct
        // has two operator() functions defined, 'Evaluate' and
        // 'GetExpression'. It is this latter one with which we are
        // concerned, as it will return to us the client's query through C
        // style reference to a C string. GetExpression is called through
        // the function table found on the filter. It takes a self pointer
        // to the filter, and two strings by C reference for the query
        // langauge and expression respectively.
        const MI_Char* lang; // string to receive the 'query language', must be "WQL"
        const MI_Char* expr; // string to receive the 'query expression', our input

        filter->ft->GetExpression(filter, &lang, &expr);

        // the query language must be WQL, so do a quick sanity check
        {
            string language(lang);
            if (language != "WQL")
            {
                throw SCXNotSupportedException(L"Query can only be made in WQL", SCXSRCLOCATION);
            }
        }

        // get our query
        string query(expr);

        // function of "get" or "list" is required
        string function(GetValueForKey("Function", query));

        // We have a well-defined interface where TargetPath is a mandatory
        // key. Parse the query to retrieve the path. Note: does not support
        // single or double quotation mark in path (nor does OMI support
        // these in a key's value).
        string path(GetValueForKey("TargetPath", query));
        SCXFilePath targetPath(SCXFileSystem::DecodePath(path));
        SCXFileInfo targetFile(targetPath); // required because IsDirectory is not static

        // enumerate the subdirectories and files given a directory
        if (StrCompare(StrFromUTF8(function), L"list", true) == 0) // compares case-insensitive
        {
            // file must exist
            if (!targetFile.PathExists())
            {
                throw MissingFile(targetPath, SCXSRCLOCATION);
            }
            // only function on directories
            else if (!targetFile.IsDirectory())
            {
                throw InvalidParameter(L"Function was 'list' but TargetPath was not a directory", SCXSRCLOCATION);
            }
            else
            {
                // We do not use an SCXDirectoryInfo object here as a) its
                // members are vectors of handles to info objects inside, but we
                // want to deal with each one individually by its path, and b)
                // we may not be dealing with a directory.
                //
                // Since we will be using a multitude of functions on each file
                // found in the directory, the PAL recommends using a
                // constructed object to avoid the overhead incurred by multiple
                // static method calls, hence the SCXFileInfo used below.
                //
                // Since this is a WQL invocation, the key (TargetPath) must
                // match for each instance returned, otherwise the OMI server
                // will filter the instance out. This is beyond our control, and
                // the requirement is satisfied by passing the original path
                // string to the EnumerateOneInstance helper function, which
                // sets the key's value to it for every instance, thus ensuring
                // all the instances are returned to the client. Any keys later
                // added in the specification must be handled in the same
                // manner.
                //
                // Because of a bug in the PAL, if the path to the directory
                // does not have a trailing slash, its base directory will
                // instead be enumerated. A work-around for this is to append
                // the missing slash.
                {
                    wstring wpath(StrFromUTF8(path));

                    wstringstream folderSeparatorStream;
                    folderSeparatorStream << SCXFilePath::GetFolderSeparator();
                    wstring folderSeparator(folderSeparatorStream.str());

                    if (wpath != folderSeparator) // skip this for root
                    {
                        if (*wpath.rbegin() != SCXFilePath::GetFolderSeparator())
                        {
                            wstringstream pathStream;
                            pathStream << wpath << SCXFilePath::GetFolderSeparator();
                            targetPath = SCXFileSystem::DecodePath(StrToUTF8(pathStream.str()));
                            targetFile = SCXFileInfo(targetPath);
                        }
                    }
                }

                // SCXDirectory in the PAL does not provide all sub-items in one
                // go, but requires using GetSysFiles for system files,
                // GetDirectories for directories, and GetFiles for regular
                // files, since we want all of them, in that order, we iterate
                // over a vector of vectors of paths (would be faster with move
                // semantics).
                vector<vector<SCXFilePath> > items;
                items.push_back(vector<SCXFilePath>(SCXDirectory::GetSysFiles(targetPath)));
                items.push_back(vector<SCXFilePath>(SCXDirectory::GetDirectories(targetPath)));
                items.push_back(vector<SCXFilePath>(SCXDirectory::GetFiles(targetPath)));

                for (vector<vector<SCXFilePath> >::iterator i(items.begin()); i != items.end(); ++i)
                {
                    for (vector<SCXFilePath>::iterator j(i->begin()); j != i->end(); ++j)
                    {
                        SCXFileInfo file(*j);
                        context.Post(EnumerateOneInstance(file, path, function));
                    }
                }
            }
        }
        // otherwise enumerate the binary contents of the file
        else if (StrCompare(StrFromUTF8(function), L"get", true) == 0) // compares case-insensitive
        {
            // file must exist
            if (!targetFile.PathExists())
            {
                throw MissingFile(targetPath, SCXSRCLOCATION);
            }
            // only function on files
            else if (targetFile.IsDirectory())
            {
                throw InvalidParameter(L"Function was 'get' but TargetPath was not a file", SCXSRCLOCATION);
            }
            else
            {
                // determine chunk size (in bytes) by trying to read it from the
                // query, catch the exception and set it to a default of 10K.
                size_t chunkBytes;
                try
                {
                    chunkBytes = StrToUInt(StrFromUTF8(GetValueForKey("ChunkBytes", query)));
                }
                catch (const MissingValue& e)
                {
                    chunkBytes = 10 * 1024;
                }

                // determine starting offset bytes from query, defaulting to 0
                // (start of file), and set max bytes from offset to end of file
                size_t offsetBytes;
                try
                {
                    offsetBytes = StrToUInt(StrFromUTF8(GetValueForKey("OffsetBytes", query)));
                }
                catch (const MissingValue& e)
                {
                    offsetBytes = 0;
                }
                size_t maxBytes(targetFile.GetSize() - offsetBytes);

                // determine total bytes to read from query, defaulting to max
                // bytes, and not exceeding max bytes
                size_t totalBytes;
                try
                {
                    totalBytes = StrToUInt(StrFromUTF8(GetValueForKey("TotalBytes", query)));
                    if (totalBytes > maxBytes)
                    {
                        totalBytes = maxBytes;
                    }
                }
                catch (const MissingValue& e)
                {
                    totalBytes = maxBytes;
                }

                validateBytes(targetFile.GetSize(), chunkBytes, offsetBytes, totalBytes);

                // calculate total chunks accounting for uneven division of file
                size_t totalChunks(totalBytes / chunkBytes);
                size_t lastChunkBytes(totalBytes % chunkBytes);
                if (lastChunkBytes != 0)
                {
                    ++totalChunks;
                }
                else
                {
                    lastChunkBytes = chunkBytes;
                }

                // enumerate an instance of the file with metadata to be copied by following loop
                const MSFT_FileBrowser_Class constInst(EnumerateOneInstance(targetFile, path, function));

                for (size_t chunk(0); chunk < totalChunks; ++chunk)
                {
                    // set size based on chunkBytes or smaller (remainder) if
                    // last chunk; if last chunk fit exactly, mod leaves 0 but
                    // we want the full chunk so reset to chunkBytes
                    size_t size(chunk == totalChunks - 1 // is last chunk?
                                ? lastChunkBytes // then fill last chunk with remaining bytes
                                : chunkBytes); // else fill entire chunk

                    // The Base64 encode function takes a vector of unsigned
                    // chars (preferred over a string because binary
                    // data). ReadAvailableBytesAsUnsigned wants a
                    // contiguous block of memory, and yes, a vector is
                    // guaranteed to be this.
                    vector<unsigned char> fileData(size);
                    // Note this may encounter a race condition where the
                    // file was deleted since the earlier check, but this
                    // PAL function does not throw anything, it simply
                    // returns an error code, and we cannot know if it was
                    // because the file was missing.
                    int errNo(SCXFile::ReadAvailableBytesAsUnsigned(targetPath, &fileData[0], size, offsetBytes + chunk * chunkBytes));
                    if (errNo != 0)
                    {
                        throw Failure(L"ReadAvailableBytesAsUnsigned returned UNIX errno: " + StrFrom<int>(errNo), SCXSRCLOCATION);
                    }

                    // encode the data into Base64 UTF-8
                    string encodedChunk; // passed by reference
                    util::Base64Helper::Encode(fileData, encodedChunk);

                    // prepare instance
                    MSFT_FileBrowser_Class inst(constInst);
                    inst.ChunkIndex_value(chunk);
                    inst.TotalChunks_value(totalChunks);
                    inst.ChunkBytes_value(size);
                    inst.OffsetBytes_value(offsetBytes);
                    inst.TotalBytes_value(totalBytes);
                    inst.Data_value(encodedChunk.c_str());
                    context.Post(inst);
                }
            }
        }
        // function was not "list" or "get"
        else
        {
            throw MissingValue("Function (one of 'list' or 'get')", query, SCXSRCLOCATION);
        }

        // if all went well and without an exception, post OK and return
        context.Post(MI_RESULT_OK);
        return;
    }

    // This exception is thrown if the provider cannot continue.
    catch (const Failure& e)
    {
        context.Post(MI_RESULT_FAILED);
        return;
    }

    // This exception is thrown if Function or TargetPath is not specified
    catch (const InvalidParameter& e)
    {
        context.Post(MI_RESULT_INVALID_PARAMETER);
        return;
    }

    // This exception is thrown by the GetValueForKey helper, if it was
    // unable to get a value for a given key in the query.
    catch (const MissingValue& e)
    {
        context.Post(MI_RESULT_INVALID_QUERY);
        return;
    }

    // This exception is thrown if EI is called directly.
    catch (const SCXNotSupportedException& e)
    {
        context.Post(MI_RESULT_NOT_SUPPORTED);
        return;
    }

    // Thrown by checks for file existence.
    catch (const MissingFile& e)
    {
        context.Post(MI_RESULT_NOT_FOUND);
        return;
    }

    // This exception is thrown by the SCXDirectory::GetThings functions,
    // which although the file's existence was checked, we might encounter a
    // race condition and still have this thrown.
    catch (const SCXFilePathNotFoundException& e)
    {
        context.Post(MI_RESULT_NOT_FOUND);
        return;
    }

    // This exception is thrown SCXFile::OpenFstream if it could not access
    // the file. Even if the requestor is root, we cannot guarantee we will
    // have access to all files (e.g. network shares, devices, etc.). If so,
    // we should return ACCESS_DENIED.
    catch (const SCXUnauthorizedFileSystemAccessException& e)
    {
        context.Post(MI_RESULT_ACCESS_DENIED);
        return;
    }

    // Catch any other exception (FUTURE: log e.what())
    catch (const exception& e)
    {
        context.Post(MI_RESULT_FAILED);
        return;
    }

    // Unknown state, nothing more to do
    catch (...)
    {
        context.Post(MI_RESULT_FAILED);
        return;
    }
}

void MSFT_FileBrowser_Class_Provider::GetInstance(
    Context& context,
    const String& nameSpace,
    const MSFT_FileBrowser_Class& instanceName,
    const PropertySet& propertySet)
{
    // The GetInstance (GI) method can be used to return exactly one
    // instance of file meta-data using the same 'EnumerateOneInstance'
    // helper that EI uses. The invocation of GI requires the name of an
    // instance, which means setting the key. Since our key is 'TargetPath',
    // it is used to determine which file we are retrieving information.
    try
    {
        const string path(instanceName.TargetPath_value().Str());
        SCXFilePath targetPath(SCXFileSystem::DecodePath(path));
        SCXFileInfo targetFile(targetPath);

        context.Post(EnumerateOneInstance(targetFile, path));
        context.Post(MI_RESULT_OK);
    }
    catch (...)
    {
        // unknown state, nothing more to do
        context.Post(MI_RESULT_FAILED);
        return;
    }
}

void MSFT_FileBrowser_Class_Provider::CreateInstance(
    Context& context,
    const String& nameSpace,
    const MSFT_FileBrowser_Class& newInstance)
{
    context.Post(MI_RESULT_NOT_SUPPORTED);
}

void MSFT_FileBrowser_Class_Provider::ModifyInstance(
    Context& context,
    const String& nameSpace,
    const MSFT_FileBrowser_Class& modifiedInstance,
    const PropertySet& propertySet)
{
    context.Post(MI_RESULT_NOT_SUPPORTED);
}

void MSFT_FileBrowser_Class_Provider::DeleteInstance(
    Context& context,
    const String& nameSpace,
    const MSFT_FileBrowser_Class& instanceName)
{
    context.Post(MI_RESULT_NOT_SUPPORTED);
}


MI_END_NAMESPACE
