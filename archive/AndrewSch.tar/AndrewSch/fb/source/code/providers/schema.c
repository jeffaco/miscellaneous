/* @migen@ */
/*
**==============================================================================
**
** WARNING: THIS FILE WAS AUTOMATICALLY GENERATED. PLEASE DO NOT EDIT.
**
**==============================================================================
*/
#include <ctype.h>
#include <MI.h>
#include "MSFT_FileBrowser.h"

/*
**==============================================================================
**
** Schema Declaration
**
**==============================================================================
*/

extern MI_SchemaDecl schemaDecl;

/*
**==============================================================================
**
** Qualifier declarations
**
**==============================================================================
*/

/*
**==============================================================================
**
** MSFT_FileBrowser
**
**==============================================================================
*/

/* property MSFT_FileBrowser.TargetPath */
static MI_CONST MI_PropertyDecl MSFT_FileBrowser_TargetPath_prop =
{
    MI_FLAG_PROPERTY|MI_FLAG_KEY, /* flags */
    0x0074680A, /* code */
    MI_T("TargetPath"), /* name */
    NULL, /* qualifiers */
    0, /* numQualifiers */
    MI_STRING, /* type */
    NULL, /* className */
    0, /* subscript */
    offsetof(MSFT_FileBrowser, TargetPath), /* offset */
    MI_T("MSFT_FileBrowser"), /* origin */
    MI_T("MSFT_FileBrowser"), /* propagator */
    NULL,
};

/* property MSFT_FileBrowser.Function */
static MI_CONST MI_PropertyDecl MSFT_FileBrowser_Function_prop =
{
    MI_FLAG_PROPERTY, /* flags */
    0x00666E08, /* code */
    MI_T("Function"), /* name */
    NULL, /* qualifiers */
    0, /* numQualifiers */
    MI_STRING, /* type */
    NULL, /* className */
    0, /* subscript */
    offsetof(MSFT_FileBrowser, Function), /* offset */
    MI_T("MSFT_FileBrowser"), /* origin */
    MI_T("MSFT_FileBrowser"), /* propagator */
    NULL,
};

/* property MSFT_FileBrowser.FullPath */
static MI_CONST MI_PropertyDecl MSFT_FileBrowser_FullPath_prop =
{
    MI_FLAG_PROPERTY, /* flags */
    0x00666808, /* code */
    MI_T("FullPath"), /* name */
    NULL, /* qualifiers */
    0, /* numQualifiers */
    MI_STRING, /* type */
    NULL, /* className */
    0, /* subscript */
    offsetof(MSFT_FileBrowser, FullPath), /* offset */
    MI_T("MSFT_FileBrowser"), /* origin */
    MI_T("MSFT_FileBrowser"), /* propagator */
    NULL,
};

/* property MSFT_FileBrowser.Name */
static MI_CONST MI_PropertyDecl MSFT_FileBrowser_Name_prop =
{
    MI_FLAG_PROPERTY, /* flags */
    0x006E6504, /* code */
    MI_T("Name"), /* name */
    NULL, /* qualifiers */
    0, /* numQualifiers */
    MI_STRING, /* type */
    NULL, /* className */
    0, /* subscript */
    offsetof(MSFT_FileBrowser, Name), /* offset */
    MI_T("MSFT_FileBrowser"), /* origin */
    MI_T("MSFT_FileBrowser"), /* propagator */
    NULL,
};

/* property MSFT_FileBrowser.FolderSeparator */
static MI_CONST MI_PropertyDecl MSFT_FileBrowser_FolderSeparator_prop =
{
    MI_FLAG_PROPERTY, /* flags */
    0x0066720F, /* code */
    MI_T("FolderSeparator"), /* name */
    NULL, /* qualifiers */
    0, /* numQualifiers */
    MI_STRING, /* type */
    NULL, /* className */
    0, /* subscript */
    offsetof(MSFT_FileBrowser, FolderSeparator), /* offset */
    MI_T("MSFT_FileBrowser"), /* origin */
    MI_T("MSFT_FileBrowser"), /* propagator */
    NULL,
};

/* property MSFT_FileBrowser.PathExists */
static MI_CONST MI_PropertyDecl MSFT_FileBrowser_PathExists_prop =
{
    MI_FLAG_PROPERTY, /* flags */
    0x0070730A, /* code */
    MI_T("PathExists"), /* name */
    NULL, /* qualifiers */
    0, /* numQualifiers */
    MI_BOOLEAN, /* type */
    NULL, /* className */
    0, /* subscript */
    offsetof(MSFT_FileBrowser, PathExists), /* offset */
    MI_T("MSFT_FileBrowser"), /* origin */
    MI_T("MSFT_FileBrowser"), /* propagator */
    NULL,
};

/* property MSFT_FileBrowser.AccessRights */
static MI_CONST MI_PropertyDecl MSFT_FileBrowser_AccessRights_prop =
{
    MI_FLAG_PROPERTY, /* flags */
    0x0061730C, /* code */
    MI_T("AccessRights"), /* name */
    NULL, /* qualifiers */
    0, /* numQualifiers */
    MI_STRING, /* type */
    NULL, /* className */
    0, /* subscript */
    offsetof(MSFT_FileBrowser, AccessRights), /* offset */
    MI_T("MSFT_FileBrowser"), /* origin */
    MI_T("MSFT_FileBrowser"), /* propagator */
    NULL,
};

/* property MSFT_FileBrowser.Directory */
static MI_CONST MI_PropertyDecl MSFT_FileBrowser_Directory_prop =
{
    MI_FLAG_PROPERTY, /* flags */
    0x00647909, /* code */
    MI_T("Directory"), /* name */
    NULL, /* qualifiers */
    0, /* numQualifiers */
    MI_BOOLEAN, /* type */
    NULL, /* className */
    0, /* subscript */
    offsetof(MSFT_FileBrowser, Directory), /* offset */
    MI_T("MSFT_FileBrowser"), /* origin */
    MI_T("MSFT_FileBrowser"), /* propagator */
    NULL,
};

/* property MSFT_FileBrowser.LastAccessTimeUTC */
static MI_CONST MI_PropertyDecl MSFT_FileBrowser_LastAccessTimeUTC_prop =
{
    MI_FLAG_PROPERTY, /* flags */
    0x006C6311, /* code */
    MI_T("LastAccessTimeUTC"), /* name */
    NULL, /* qualifiers */
    0, /* numQualifiers */
    MI_STRING, /* type */
    NULL, /* className */
    0, /* subscript */
    offsetof(MSFT_FileBrowser, LastAccessTimeUTC), /* offset */
    MI_T("MSFT_FileBrowser"), /* origin */
    MI_T("MSFT_FileBrowser"), /* propagator */
    NULL,
};

/* property MSFT_FileBrowser.LastModificationTimeUTC */
static MI_CONST MI_PropertyDecl MSFT_FileBrowser_LastModificationTimeUTC_prop =
{
    MI_FLAG_PROPERTY, /* flags */
    0x006C6317, /* code */
    MI_T("LastModificationTimeUTC"), /* name */
    NULL, /* qualifiers */
    0, /* numQualifiers */
    MI_STRING, /* type */
    NULL, /* className */
    0, /* subscript */
    offsetof(MSFT_FileBrowser, LastModificationTimeUTC), /* offset */
    MI_T("MSFT_FileBrowser"), /* origin */
    MI_T("MSFT_FileBrowser"), /* propagator */
    NULL,
};

/* property MSFT_FileBrowser.LastStatusChangeTimeUTC */
static MI_CONST MI_PropertyDecl MSFT_FileBrowser_LastStatusChangeTimeUTC_prop =
{
    MI_FLAG_PROPERTY, /* flags */
    0x006C6317, /* code */
    MI_T("LastStatusChangeTimeUTC"), /* name */
    NULL, /* qualifiers */
    0, /* numQualifiers */
    MI_STRING, /* type */
    NULL, /* className */
    0, /* subscript */
    offsetof(MSFT_FileBrowser, LastStatusChangeTimeUTC), /* offset */
    MI_T("MSFT_FileBrowser"), /* origin */
    MI_T("MSFT_FileBrowser"), /* propagator */
    NULL,
};

/* property MSFT_FileBrowser.LinkCount */
static MI_CONST MI_PropertyDecl MSFT_FileBrowser_LinkCount_prop =
{
    MI_FLAG_PROPERTY, /* flags */
    0x006C7409, /* code */
    MI_T("LinkCount"), /* name */
    NULL, /* qualifiers */
    0, /* numQualifiers */
    MI_UINT64, /* type */
    NULL, /* className */
    0, /* subscript */
    offsetof(MSFT_FileBrowser, LinkCount), /* offset */
    MI_T("MSFT_FileBrowser"), /* origin */
    MI_T("MSFT_FileBrowser"), /* propagator */
    NULL,
};

/* property MSFT_FileBrowser.Size */
static MI_CONST MI_PropertyDecl MSFT_FileBrowser_Size_prop =
{
    MI_FLAG_PROPERTY, /* flags */
    0x00736504, /* code */
    MI_T("Size"), /* name */
    NULL, /* qualifiers */
    0, /* numQualifiers */
    MI_UINT64, /* type */
    NULL, /* className */
    0, /* subscript */
    offsetof(MSFT_FileBrowser, Size), /* offset */
    MI_T("MSFT_FileBrowser"), /* origin */
    MI_T("MSFT_FileBrowser"), /* propagator */
    NULL,
};

/* property MSFT_FileBrowser.BlockSize */
static MI_CONST MI_PropertyDecl MSFT_FileBrowser_BlockSize_prop =
{
    MI_FLAG_PROPERTY, /* flags */
    0x00626509, /* code */
    MI_T("BlockSize"), /* name */
    NULL, /* qualifiers */
    0, /* numQualifiers */
    MI_UINT64, /* type */
    NULL, /* className */
    0, /* subscript */
    offsetof(MSFT_FileBrowser, BlockSize), /* offset */
    MI_T("MSFT_FileBrowser"), /* origin */
    MI_T("MSFT_FileBrowser"), /* propagator */
    NULL,
};

/* property MSFT_FileBrowser.BlockCount */
static MI_CONST MI_PropertyDecl MSFT_FileBrowser_BlockCount_prop =
{
    MI_FLAG_PROPERTY, /* flags */
    0x0062740A, /* code */
    MI_T("BlockCount"), /* name */
    NULL, /* qualifiers */
    0, /* numQualifiers */
    MI_UINT64, /* type */
    NULL, /* className */
    0, /* subscript */
    offsetof(MSFT_FileBrowser, BlockCount), /* offset */
    MI_T("MSFT_FileBrowser"), /* origin */
    MI_T("MSFT_FileBrowser"), /* propagator */
    NULL,
};

/* property MSFT_FileBrowser.UserID */
static MI_CONST MI_PropertyDecl MSFT_FileBrowser_UserID_prop =
{
    MI_FLAG_PROPERTY, /* flags */
    0x00756406, /* code */
    MI_T("UserID"), /* name */
    NULL, /* qualifiers */
    0, /* numQualifiers */
    MI_UINT32, /* type */
    NULL, /* className */
    0, /* subscript */
    offsetof(MSFT_FileBrowser, UserID), /* offset */
    MI_T("MSFT_FileBrowser"), /* origin */
    MI_T("MSFT_FileBrowser"), /* propagator */
    NULL,
};

/* property MSFT_FileBrowser.GroupID */
static MI_CONST MI_PropertyDecl MSFT_FileBrowser_GroupID_prop =
{
    MI_FLAG_PROPERTY, /* flags */
    0x00676407, /* code */
    MI_T("GroupID"), /* name */
    NULL, /* qualifiers */
    0, /* numQualifiers */
    MI_UINT32, /* type */
    NULL, /* className */
    0, /* subscript */
    offsetof(MSFT_FileBrowser, GroupID), /* offset */
    MI_T("MSFT_FileBrowser"), /* origin */
    MI_T("MSFT_FileBrowser"), /* propagator */
    NULL,
};

/* property MSFT_FileBrowser.Device */
static MI_CONST MI_PropertyDecl MSFT_FileBrowser_Device_prop =
{
    MI_FLAG_PROPERTY, /* flags */
    0x00646506, /* code */
    MI_T("Device"), /* name */
    NULL, /* qualifiers */
    0, /* numQualifiers */
    MI_UINT64, /* type */
    NULL, /* className */
    0, /* subscript */
    offsetof(MSFT_FileBrowser, Device), /* offset */
    MI_T("MSFT_FileBrowser"), /* origin */
    MI_T("MSFT_FileBrowser"), /* propagator */
    NULL,
};

/* property MSFT_FileBrowser.DeviceNumber */
static MI_CONST MI_PropertyDecl MSFT_FileBrowser_DeviceNumber_prop =
{
    MI_FLAG_PROPERTY, /* flags */
    0x0064720C, /* code */
    MI_T("DeviceNumber"), /* name */
    NULL, /* qualifiers */
    0, /* numQualifiers */
    MI_UINT64, /* type */
    NULL, /* className */
    0, /* subscript */
    offsetof(MSFT_FileBrowser, DeviceNumber), /* offset */
    MI_T("MSFT_FileBrowser"), /* origin */
    MI_T("MSFT_FileBrowser"), /* propagator */
    NULL,
};

/* property MSFT_FileBrowser.SerialNumber */
static MI_CONST MI_PropertyDecl MSFT_FileBrowser_SerialNumber_prop =
{
    MI_FLAG_PROPERTY, /* flags */
    0x0073720C, /* code */
    MI_T("SerialNumber"), /* name */
    NULL, /* qualifiers */
    0, /* numQualifiers */
    MI_UINT64, /* type */
    NULL, /* className */
    0, /* subscript */
    offsetof(MSFT_FileBrowser, SerialNumber), /* offset */
    MI_T("MSFT_FileBrowser"), /* origin */
    MI_T("MSFT_FileBrowser"), /* propagator */
    NULL,
};

/* property MSFT_FileBrowser.ChunkIndex */
static MI_CONST MI_PropertyDecl MSFT_FileBrowser_ChunkIndex_prop =
{
    MI_FLAG_PROPERTY, /* flags */
    0x0063780A, /* code */
    MI_T("ChunkIndex"), /* name */
    NULL, /* qualifiers */
    0, /* numQualifiers */
    MI_UINT64, /* type */
    NULL, /* className */
    0, /* subscript */
    offsetof(MSFT_FileBrowser, ChunkIndex), /* offset */
    MI_T("MSFT_FileBrowser"), /* origin */
    MI_T("MSFT_FileBrowser"), /* propagator */
    NULL,
};

/* property MSFT_FileBrowser.TotalChunks */
static MI_CONST MI_PropertyDecl MSFT_FileBrowser_TotalChunks_prop =
{
    MI_FLAG_PROPERTY, /* flags */
    0x0074730B, /* code */
    MI_T("TotalChunks"), /* name */
    NULL, /* qualifiers */
    0, /* numQualifiers */
    MI_UINT64, /* type */
    NULL, /* className */
    0, /* subscript */
    offsetof(MSFT_FileBrowser, TotalChunks), /* offset */
    MI_T("MSFT_FileBrowser"), /* origin */
    MI_T("MSFT_FileBrowser"), /* propagator */
    NULL,
};

/* property MSFT_FileBrowser.ChunkBytes */
static MI_CONST MI_PropertyDecl MSFT_FileBrowser_ChunkBytes_prop =
{
    MI_FLAG_PROPERTY, /* flags */
    0x0063730A, /* code */
    MI_T("ChunkBytes"), /* name */
    NULL, /* qualifiers */
    0, /* numQualifiers */
    MI_UINT64, /* type */
    NULL, /* className */
    0, /* subscript */
    offsetof(MSFT_FileBrowser, ChunkBytes), /* offset */
    MI_T("MSFT_FileBrowser"), /* origin */
    MI_T("MSFT_FileBrowser"), /* propagator */
    NULL,
};

/* property MSFT_FileBrowser.OffsetBytes */
static MI_CONST MI_PropertyDecl MSFT_FileBrowser_OffsetBytes_prop =
{
    MI_FLAG_PROPERTY, /* flags */
    0x006F730B, /* code */
    MI_T("OffsetBytes"), /* name */
    NULL, /* qualifiers */
    0, /* numQualifiers */
    MI_UINT64, /* type */
    NULL, /* className */
    0, /* subscript */
    offsetof(MSFT_FileBrowser, OffsetBytes), /* offset */
    MI_T("MSFT_FileBrowser"), /* origin */
    MI_T("MSFT_FileBrowser"), /* propagator */
    NULL,
};

/* property MSFT_FileBrowser.TotalBytes */
static MI_CONST MI_PropertyDecl MSFT_FileBrowser_TotalBytes_prop =
{
    MI_FLAG_PROPERTY, /* flags */
    0x0074730A, /* code */
    MI_T("TotalBytes"), /* name */
    NULL, /* qualifiers */
    0, /* numQualifiers */
    MI_UINT64, /* type */
    NULL, /* className */
    0, /* subscript */
    offsetof(MSFT_FileBrowser, TotalBytes), /* offset */
    MI_T("MSFT_FileBrowser"), /* origin */
    MI_T("MSFT_FileBrowser"), /* propagator */
    NULL,
};

/* property MSFT_FileBrowser.Data */
static MI_CONST MI_PropertyDecl MSFT_FileBrowser_Data_prop =
{
    MI_FLAG_PROPERTY, /* flags */
    0x00646104, /* code */
    MI_T("Data"), /* name */
    NULL, /* qualifiers */
    0, /* numQualifiers */
    MI_STRING, /* type */
    NULL, /* className */
    0, /* subscript */
    offsetof(MSFT_FileBrowser, Data), /* offset */
    MI_T("MSFT_FileBrowser"), /* origin */
    MI_T("MSFT_FileBrowser"), /* propagator */
    NULL,
};

static MI_PropertyDecl MI_CONST* MI_CONST MSFT_FileBrowser_props[] =
{
    &MSFT_FileBrowser_TargetPath_prop,
    &MSFT_FileBrowser_Function_prop,
    &MSFT_FileBrowser_FullPath_prop,
    &MSFT_FileBrowser_Name_prop,
    &MSFT_FileBrowser_FolderSeparator_prop,
    &MSFT_FileBrowser_PathExists_prop,
    &MSFT_FileBrowser_AccessRights_prop,
    &MSFT_FileBrowser_Directory_prop,
    &MSFT_FileBrowser_LastAccessTimeUTC_prop,
    &MSFT_FileBrowser_LastModificationTimeUTC_prop,
    &MSFT_FileBrowser_LastStatusChangeTimeUTC_prop,
    &MSFT_FileBrowser_LinkCount_prop,
    &MSFT_FileBrowser_Size_prop,
    &MSFT_FileBrowser_BlockSize_prop,
    &MSFT_FileBrowser_BlockCount_prop,
    &MSFT_FileBrowser_UserID_prop,
    &MSFT_FileBrowser_GroupID_prop,
    &MSFT_FileBrowser_Device_prop,
    &MSFT_FileBrowser_DeviceNumber_prop,
    &MSFT_FileBrowser_SerialNumber_prop,
    &MSFT_FileBrowser_ChunkIndex_prop,
    &MSFT_FileBrowser_TotalChunks_prop,
    &MSFT_FileBrowser_ChunkBytes_prop,
    &MSFT_FileBrowser_OffsetBytes_prop,
    &MSFT_FileBrowser_TotalBytes_prop,
    &MSFT_FileBrowser_Data_prop,
};

static MI_CONST MI_ProviderFT MSFT_FileBrowser_funcs =
{
  (MI_ProviderFT_Load)MSFT_FileBrowser_Load,
  (MI_ProviderFT_Unload)MSFT_FileBrowser_Unload,
  (MI_ProviderFT_GetInstance)MSFT_FileBrowser_GetInstance,
  (MI_ProviderFT_EnumerateInstances)MSFT_FileBrowser_EnumerateInstances,
  (MI_ProviderFT_CreateInstance)MSFT_FileBrowser_CreateInstance,
  (MI_ProviderFT_ModifyInstance)MSFT_FileBrowser_ModifyInstance,
  (MI_ProviderFT_DeleteInstance)MSFT_FileBrowser_DeleteInstance,
  (MI_ProviderFT_AssociatorInstances)NULL,
  (MI_ProviderFT_ReferenceInstances)NULL,
  (MI_ProviderFT_EnableIndications)NULL,
  (MI_ProviderFT_DisableIndications)NULL,
  (MI_ProviderFT_Subscribe)NULL,
  (MI_ProviderFT_Unsubscribe)NULL,
  (MI_ProviderFT_Invoke)NULL,
};

static MI_CONST MI_Char* MSFT_FileBrowser_Version_qual_value = MI_T("0.0.1");

static MI_CONST MI_Qualifier MSFT_FileBrowser_Version_qual =
{
    MI_T("Version"),
    MI_STRING,
    MI_FLAG_ENABLEOVERRIDE|MI_FLAG_TRANSLATABLE|MI_FLAG_RESTRICTED,
    &MSFT_FileBrowser_Version_qual_value
};

static MI_Qualifier MI_CONST* MI_CONST MSFT_FileBrowser_quals[] =
{
    &MSFT_FileBrowser_Version_qual,
};

/* class MSFT_FileBrowser */
MI_CONST MI_ClassDecl MSFT_FileBrowser_rtti =
{
    MI_FLAG_CLASS, /* flags */
    0x006D7210, /* code */
    MI_T("MSFT_FileBrowser"), /* name */
    MSFT_FileBrowser_quals, /* qualifiers */
    MI_COUNT(MSFT_FileBrowser_quals), /* numQualifiers */
    MSFT_FileBrowser_props, /* properties */
    MI_COUNT(MSFT_FileBrowser_props), /* numProperties */
    sizeof(MSFT_FileBrowser), /* size */
    NULL, /* superClass */
    NULL, /* superClassDecl */
    NULL, /* methods */
    0, /* numMethods */
    &schemaDecl, /* schema */
    &MSFT_FileBrowser_funcs, /* functions */
    NULL, /* owningClass */
};

/*
**==============================================================================
**
** __mi_server
**
**==============================================================================
*/

MI_Server* __mi_server;
/*
**==============================================================================
**
** Schema
**
**==============================================================================
*/

static MI_ClassDecl MI_CONST* MI_CONST classes[] =
{
    &MSFT_FileBrowser_rtti,
};

MI_SchemaDecl schemaDecl =
{
    NULL, /* qualifierDecls */
    0, /* numQualifierDecls */
    classes, /* classDecls */
    MI_COUNT(classes), /* classDecls */
};

/*
**==============================================================================
**
** MI_Server Methods
**
**==============================================================================
*/

MI_Result MI_CALL MI_Server_GetVersion(
    MI_Uint32* version){
    return __mi_server->serverFT->GetVersion(version);
}

MI_Result MI_CALL MI_Server_GetSystemName(
    const MI_Char** systemName)
{
    return __mi_server->serverFT->GetSystemName(systemName);
}

