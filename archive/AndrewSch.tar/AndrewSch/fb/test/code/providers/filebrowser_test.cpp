#include <algorithm>
#include <iostream>
#include <string>
#include <sstream>

#include <scxcorelib/scxcmn.h>
#include <scxcorelib/scxdirectoryinfo.h>
#include <scxcorelib/scxexception.h>
#include <scxcorelib/scxfile.h>
#include <scxcorelib/scxfilesystem.h>
#include <scxcorelib/stringaid.h>

#include <testutils/scxunit.h>
#include <testutils/providertestutils.h>

#include "MSFT_FileBrowser_Class_Provider.h"


using namespace std;
using namespace SCXCoreLib;

class FileBrowser_Test: public CppUnit::TestFixture
{
    // Beginning of test suite declartions
    CPPUNIT_TEST_SUITE(FileBrowser_Test);

    CPPUNIT_TEST(testEnumerateInstancesWithoutFilter);
    CPPUNIT_TEST(testEnumerateInstancesWithMissingTargetPath);
    CPPUNIT_TEST(testEnumerateInstancesWithMissingFunction);
    CPPUNIT_TEST(testEnumerateInstancesWithExtraKeys);
    CPPUNIT_TEST(testEnumerateInstancesWithMalformedValue);

    CPPUNIT_TEST(testEnumerateInstancesWithDirectoryAndFunctionList);
    CPPUNIT_TEST(testEnumerateInstancesWithDirectoryAndFunctionLIST);
    CPPUNIT_TEST(testEnumerateInstancesWithDirectoryAndFunctionGet);
    CPPUNIT_TEST(testEnumerateInstancesWithFullDirectory);

    CPPUNIT_TEST(testEnumerateInstancesWithFileAndFunctionGet);
    CPPUNIT_TEST(testEnumerateInstancesWithFileAndFunctionGET);
    CPPUNIT_TEST(testEnumerateInstancesWithFileAndFunctionList);

    CPPUNIT_TEST(testEnumerateInstancesWithMissingDirectory);
    CPPUNIT_TEST(testEnumerateInstancesWithMissingFile);

    CPPUNIT_TEST(testEnumerateInstancesWithTempFile);
    CPPUNIT_TEST(testEnumerateInstancesWithTempDirectory);
    CPPUNIT_TEST(testEnumerateInstancesWithTrailingSlash);

    CPPUNIT_TEST(testEnumerateInstancesWithTwoChunks);
    CPPUNIT_TEST(testEnumerateInstancesWithGoodOffset);
    CPPUNIT_TEST(testEnumerateInstancesWithBadOffset);
    CPPUNIT_TEST(testEnumerateInstancesWithZeroChunkBytes);

    CPPUNIT_TEST(testGetInstanceWithDirectory);
    CPPUNIT_TEST(testGetInstanceWithFile);

    CPPUNIT_TEST(testCreateInstance);
    CPPUNIT_TEST(testModifyInstance);
    CPPUNIT_TEST(testDeleteInstance);

    // End of test suite
    CPPUNIT_TEST_SUITE_END();

public:
    // helpers
    void setUp();
    void tearDown();

    // tests
    void testEnumerateInstancesWithoutFilter();
    void testEnumerateInstancesWithMissingTargetPath();
    void testEnumerateInstancesWithMissingFunction();
    void testEnumerateInstancesWithExtraKeys();
    void testEnumerateInstancesWithMalformedValue();

    void testEnumerateInstancesWithDirectoryAndFunctionList();
    void testEnumerateInstancesWithDirectoryAndFunctionLIST();
    void testEnumerateInstancesWithDirectoryAndFunctionGet();
    void testEnumerateInstancesWithFullDirectory();

    void testEnumerateInstancesWithFileAndFunctionGet();
    void testEnumerateInstancesWithFileAndFunctionGET();
    void testEnumerateInstancesWithFileAndFunctionList();

    void testEnumerateInstancesWithMissingDirectory();
    void testEnumerateInstancesWithMissingFile();

    void testEnumerateInstancesWithTwoChunks();
    void testEnumerateInstancesWithGoodOffset();
    void testEnumerateInstancesWithBadOffset();
    void testEnumerateInstancesWithZeroChunkBytes();

    void testEnumerateInstancesWithTempFile();
    void testEnumerateInstancesWithTempDirectory();
    void testEnumerateInstancesWithTrailingSlash();

    void testEnumerateInstancesWithInaccessibleDirectory();
    void testEnumerateInstancesWithInaccessibleFile();

    void testGetInstanceWithDirectory();
    void testGetInstanceWithFile();

    void testCreateInstance();
    void testModifyInstance();
    void testDeleteInstance();

private:
    void validateInstance(const TestableContext&, wstring);

    vector<wstring> m_keyNames;
};

void FileBrowser_Test::setUp()
{
    wstring errMsg; // used to send error message to testrunner (part of framework)
    TestableContext context; // mock context for calls to the provider
    SetUpAgent<mi::MSFT_FileBrowser_Class_Provider>(context, CALL_LOCATION(errMsg)); // testable provider
    // this provider should *not* call RefuseUnload
    CPPUNIT_ASSERT_EQUAL_MESSAGE(ERROR_MESSAGE, false, context.WasRefuseUnloadCalled());
    // add key name
    m_keyNames.push_back(L"TargetPath");
}

void FileBrowser_Test::tearDown()
{
    wstring errMsg;
    TestableContext context;
    TearDownAgent<mi::MSFT_FileBrowser_Class_Provider>(context, CALL_LOCATION(errMsg));
    CPPUNIT_ASSERT_EQUAL_MESSAGE(ERROR_MESSAGE, false, context.WasRefuseUnloadCalled());
}

// helper to validate instance (with any values)
void FileBrowser_Test::validateInstance(const TestableContext& context, wstring errMsg)
{
    // test the first instance from the context (should always be MSFT_FileBrowser)
    const TestableInstance &instance = context[0];
    // assert the key "TargetPath" exists
    CPPUNIT_ASSERT_EQUAL_MESSAGE(ERROR_MESSAGE, m_keyNames[0], instance.GetKeyName(0, CALL_LOCATION(errMsg)));
    CPPUNIT_ASSERT_EQUAL_MESSAGE(ERROR_MESSAGE, L"TargetPath", instance.GetKeyName(0, CALL_LOCATION(errMsg)));
    // TODO: refactor these arrays to use m_propertyNames vector
    // list of expected properties for an MSFT_FileBrowser instance
    wstring expectedProperties[] = {L"TargetPath",
                                    L"FullPath",
                                    L"Name",
                                    L"FolderSeparator",
                                    L"PathExists",
                                    L"AccessRights",
                                    L"Directory",
                                    L"LastAccessTimeUTC",
                                    L"LastModificationTimeUTC",
                                    L"LastStatusChangeTimeUTC",
                                    L"LinkCount",
                                    L"Size",
                                    L"BlockSize",
                                    L"BlockCount",
                                    L"UserID",
                                    L"GroupID",
                                    L"Device",
                                    L"DeviceNumber",
                                    L"SerialNumber"};
    // list of possible properties for an MSFT_FileBrowser instance (only appear for file retrieval)
    wstring possibleProperties[] = {L"ChunkIndex",
                                    L"TotalChunks",
                                    L"ChunkBytes",
                                    L"OffsetBytes",
                                    L"TotalBytes",
                                    L"Data"};
    // number of expected properties for an instance (too bad it is not a vector)
    const size_t expectedCount(sizeof(expectedProperties) / sizeof(expectedProperties[0]));
    const size_t possibleCount(sizeof(possibleProperties) / sizeof(possibleProperties[0]));
    // use providertestutils helper to verify the instance against its expected properties
    VerifyInstancePropertyNames(instance, expectedProperties, expectedCount, possibleProperties, possibleCount, CALL_LOCATION(errMsg));
}

void FileBrowser_Test::testEnumerateInstancesWithoutFilter()
{

    wstring errMsg;
    TestableContext context;
    MI_Result result(EnumerateInstancesResult<mi::MSFT_FileBrowser_Class_Provider>(context, CALL_LOCATION(errMsg)));
    CPPUNIT_ASSERT_EQUAL(MI_RESULT_NOT_SUPPORTED, result);
}

void FileBrowser_Test::testEnumerateInstancesWithMissingTargetPath()
{
    wstring errMsg;
    TestableContext context;
    MI_Filter filter(TestableFilter::SetUp("SELECT * FROM MSFT_FileBrowser WHERE Function='list'")); // missing TargetPath
    MI_Result result(EnumerateInstancesResult<mi::MSFT_FileBrowser_Class_Provider>(context, CALL_LOCATION(errMsg), false, &filter));
    CPPUNIT_ASSERT_EQUAL(MI_RESULT_INVALID_QUERY, result);
};

void FileBrowser_Test::testEnumerateInstancesWithMissingFunction()
{
    wstring errMsg;
    TestableContext context;
    MI_Filter filter(TestableFilter::SetUp("SELECT * FROM MSFT_FileBrowser WHERE TargetPath='/foo/bar'")); // missing TargetPath
    MI_Result result(EnumerateInstancesResult<mi::MSFT_FileBrowser_Class_Provider>(context, CALL_LOCATION(errMsg), false, &filter));
    CPPUNIT_ASSERT_EQUAL(MI_RESULT_INVALID_QUERY, result);
};

void FileBrowser_Test::testEnumerateInstancesWithExtraKeys()
{
    wstring errMsg;
    TestableContext context;
    MI_Filter filter(TestableFilter::SetUp("SELECT * FROM MSFT_FileBrowser WHERE TargetPath='/' AND Function='list' AND FullPath='/'")); // extra key
    MI_Result result(EnumerateInstancesResult<mi::MSFT_FileBrowser_Class_Provider>(context, CALL_LOCATION(errMsg), false, &filter));
    CPPUNIT_ASSERT_EQUAL(MI_RESULT_OK, result);
};

void FileBrowser_Test::testEnumerateInstancesWithMalformedValue()
{
    wstring errMsg;
    TestableContext context;
    MI_Filter filter(TestableFilter::SetUp("SELECT * FROM MSFT_FileBrowser WHERE TargetPath=/ AND Function=get")); // missing first quote (malformed)
    MI_Result result(EnumerateInstancesResult<mi::MSFT_FileBrowser_Class_Provider>(context, CALL_LOCATION(errMsg), false, &filter));
    CPPUNIT_ASSERT_EQUAL(MI_RESULT_INVALID_QUERY, result);
}

void FileBrowser_Test::testEnumerateInstancesWithDirectoryAndFunctionList()
{
    wstring errMsg;
    TestableContext context; // passed by reference to EI

    // setup test file using the PAL
    SCXDirectoryInfo tempDir(SCXDirectory::CreateTempDirectory());
    SCXFilePath tempSCXPath(tempDir.GetFullPath());
    CPPUNIT_ASSERT(SCXDirectory::Exists(tempSCXPath));

    // get the path to our test file and setup the query and filter
    string tempPath(SCXFileSystem::EncodePath(tempSCXPath));
    string query("SELECT * FROM MSFT_FileBrowser WHERE TargetPath = '" + tempPath + "' OR Function = 'list'");
    MI_Filter filter(TestableFilter::SetUp(query));

    // with function 'list' should pass
    MI_Result result(EnumerateInstancesResult<mi::MSFT_FileBrowser_Class_Provider>(context, CALL_LOCATION(errMsg), false, &filter));

    // clean up our temp file
    SCXDirectory::Delete(tempSCXPath);
    CPPUNIT_ASSERT(!SCXDirectory::Exists(tempSCXPath));

    CPPUNIT_ASSERT_EQUAL(MI_RESULT_OK, result);
}

void FileBrowser_Test::testEnumerateInstancesWithDirectoryAndFunctionLIST()
{
    wstring errMsg;
    TestableContext context; // passed by reference to EI

    // setup test file using the PAL
    SCXDirectoryInfo tempDir(SCXDirectory::CreateTempDirectory());
    SCXFilePath tempSCXPath(tempDir.GetFullPath());
    CPPUNIT_ASSERT(SCXDirectory::Exists(tempSCXPath));

    // get the path to our test file and setup the query and filter
    string tempPath(SCXFileSystem::EncodePath(tempSCXPath));
    string query("SELECT * FROM MSFT_FileBrowser WHERE TargetPath = '" + tempPath + "' OR Function = 'LIST'");
    MI_Filter filter(TestableFilter::SetUp(query));

    // with function 'list' should pass
    MI_Result result(EnumerateInstancesResult<mi::MSFT_FileBrowser_Class_Provider>(context, CALL_LOCATION(errMsg), false, &filter));

    // clean up our temp file
    SCXDirectory::Delete(tempSCXPath);
    CPPUNIT_ASSERT(!SCXDirectory::Exists(tempSCXPath));

    CPPUNIT_ASSERT_EQUAL(MI_RESULT_OK, result);
}

void FileBrowser_Test::testEnumerateInstancesWithDirectoryAndFunctionGet()
{
    wstring errMsg;
    TestableContext context; // passed by reference to EI

    // setup test file using the PAL
    SCXDirectoryInfo tempDir(SCXDirectory::CreateTempDirectory());
    SCXFilePath tempSCXPath(tempDir.GetFullPath());
    CPPUNIT_ASSERT(SCXDirectory::Exists(tempSCXPath));

    // get the path to our test file and setup the query and filter
    string tempPath(SCXFileSystem::EncodePath(tempSCXPath));
    string query("SELECT * FROM MSFT_FileBrowser WHERE TargetPath = '" + tempPath + "' OR Function = 'get'");
    MI_Filter filter(TestableFilter::SetUp(query));

    // with function 'get' should fail
    MI_Result result(EnumerateInstancesResult<mi::MSFT_FileBrowser_Class_Provider>(context, CALL_LOCATION(errMsg), false, &filter));

    // clean up our temp file
    SCXDirectory::Delete(tempSCXPath);
    CPPUNIT_ASSERT(!SCXDirectory::Exists(tempSCXPath));

    CPPUNIT_ASSERT_EQUAL(MI_RESULT_INVALID_PARAMETER, result);
}

void FileBrowser_Test::testEnumerateInstancesWithFullDirectory()
{
    wstring errMsg;
    TestableContext context; // passed by reference to EI

    // setup test file using the PAL
    SCXDirectoryInfo tempDir(SCXDirectory::CreateTempDirectory());
    // encoding and decoding is a work-around for a nasty PAL bug that
    // confuses a directory without trailing slash for its parent directory
    SCXFilePath tempDirPath(tempDir.GetFullPath());
    CPPUNIT_ASSERT(SCXDirectory::Exists(tempDirPath));

    wstring tempDirString(tempDirPath.Get());
    if (*tempDirString.rbegin() != SCXFilePath::GetFolderSeparator())
    {
        wstringstream ss;
        ss << tempDirString << SCXFilePath::GetFolderSeparator();
        tempDirString = ss.str();
    }

    wstring tempSuffix(L"somefile");
    SCXFilePath tempFilePath(tempDirString + tempSuffix);
    {
        // add files to directory
        SCXHandle<wfstream> tempFileStream(SCXFile::OpenWFstream(tempFilePath, ios_base::out));
        *tempFileStream << tempSuffix << endl;
        tempFileStream->close();
        CPPUNIT_ASSERT(SCXFile::Exists(tempFilePath));
    }

    // get the path to our test file and setup the query and filter
    string query("SELECT * FROM MSFT_FileBrowser WHERE TargetPath = '" + StrToUTF8(tempDirPath.Get()) + "' OR Function = 'list'");
    MI_Filter filter(TestableFilter::SetUp(query));

    // with function 'list' should pass
    EnumInstances<mi::MSFT_FileBrowser_Class_Provider>(context, CALL_LOCATION(errMsg), false, &filter);

    // clean up our temp directory recursively
    SCXFilePath tempDirFixed(tempDirString);
    SCXDirectory::Delete(tempDirFixed, true);
    CPPUNIT_ASSERT(!SCXDirectory::Exists(tempDirPath));

    wstringstream ss;
    ss << SCXFilePath::GetFolderSeparator();
    wstring folderSeparator(ss.str());

    const vector<TestableInstance>& instances(context.GetInstances());
    CPPUNIT_ASSERT_EQUAL(static_cast<size_t>(1), instances.size());
    const TestableInstance inst(instances[0]);
    CPPUNIT_ASSERT_EQUAL(tempDirPath.Get(), inst.GetProperty(L"TargetPath", CALL_LOCATION(errMsg)).GetValue_MIString(CALL_LOCATION(errMsg)));
    CPPUNIT_ASSERT_EQUAL(L"list", inst.GetProperty(L"Function", CALL_LOCATION(errMsg)).GetValue_MIString(CALL_LOCATION(errMsg)));
    CPPUNIT_ASSERT_EQUAL(tempFilePath.Get(), inst.GetProperty(L"FullPath", CALL_LOCATION(errMsg)).GetValue_MIString(CALL_LOCATION(errMsg)));
    CPPUNIT_ASSERT_EQUAL(tempFilePath.GetFilename(), inst.GetProperty(L"Name", CALL_LOCATION(errMsg)).GetValue_MIString(CALL_LOCATION(errMsg)));
    CPPUNIT_ASSERT_EQUAL(folderSeparator, inst.GetProperty(L"FolderSeparator", CALL_LOCATION(errMsg)).GetValue_MIString(CALL_LOCATION(errMsg)));
    CPPUNIT_ASSERT_EQUAL(true, inst.GetProperty(L"PathExists", CALL_LOCATION(errMsg)).GetValue_MIBoolean(CALL_LOCATION(errMsg)));
    CPPUNIT_ASSERT_EQUAL(false, inst.GetProperty(L"Directory", CALL_LOCATION(errMsg)).GetValue_MIBoolean(CALL_LOCATION(errMsg)));
    CPPUNIT_ASSERT_EQUAL(9, inst.GetProperty(L"Size", CALL_LOCATION(errMsg)).GetValue_MIUint64(CALL_LOCATION(errMsg)));
}

void FileBrowser_Test::testEnumerateInstancesWithFileAndFunctionGet()
{
    wstring errMsg;
    TestableContext context; // passed by reference to EI

    // setup test file using the PAL
    SCXFilePath tempFile(SCXFile::CreateTempFile(L"somefile"));
    CPPUNIT_ASSERT(SCXFile::Exists(tempFile));

    // get the path to our test file and setup the query and filter
    string tempPath(SCXFileSystem::EncodePath(tempFile));
    string query("SELECT * FROM MSFT_FileBrowser WHERE TargetPath='" + tempPath + "' or Function = 'get'");
    MI_Filter filter(TestableFilter::SetUp(query, "WQL"));

    // with function "get", should pass
    MI_Result result(EnumerateInstancesResult<mi::MSFT_FileBrowser_Class_Provider>(context, CALL_LOCATION(errMsg), false, &filter));

    // clean up our temp file
    SCXFile::Delete(tempFile);
    CPPUNIT_ASSERT(!SCXFile::Exists(tempFile));

    CPPUNIT_ASSERT_EQUAL(MI_RESULT_OK, result);
}

void FileBrowser_Test::testEnumerateInstancesWithFileAndFunctionGET()
{
    wstring errMsg;
    TestableContext context; // passed by reference to EI

    // setup test file using the PAL
    SCXFilePath tempFile(SCXFile::CreateTempFile(L"somefile"));
    CPPUNIT_ASSERT(SCXFile::Exists(tempFile));

    // get the path to our test file and setup the query and filter
    string tempPath(SCXFileSystem::EncodePath(tempFile));
    string query("SELECT * FROM MSFT_FileBrowser WHERE TargetPath='" + tempPath + "' or Function = 'GET'");
    MI_Filter filter(TestableFilter::SetUp(query, "WQL"));

    // with function "get", should pass
    MI_Result result(EnumerateInstancesResult<mi::MSFT_FileBrowser_Class_Provider>(context, CALL_LOCATION(errMsg), false, &filter));

    // clean up our temp file
    SCXFile::Delete(tempFile);
    CPPUNIT_ASSERT(!SCXFile::Exists(tempFile));

    CPPUNIT_ASSERT_EQUAL(MI_RESULT_OK, result);
}

void FileBrowser_Test::testEnumerateInstancesWithFileAndFunctionList()
{
    wstring errMsg;
    TestableContext context; // passed by reference to EI

    // setup test file using the PAL
    SCXFilePath tempFile(SCXFile::CreateTempFile(L"somefile"));
    CPPUNIT_ASSERT(SCXFile::Exists(tempFile));

    // get the path to our test file and setup the query and filter
    string tempPath(SCXFileSystem::EncodePath(tempFile));
    string query("SELECT * FROM MSFT_FileBrowser WHERE TargetPath='" + tempPath + "' or Function = 'list'");
    MI_Filter filter(TestableFilter::SetUp(query, "WQL"));

    // with function "list", should fail
    MI_Result result(EnumerateInstancesResult<mi::MSFT_FileBrowser_Class_Provider>(context, CALL_LOCATION(errMsg), false, &filter));

    // clean up our temp file
    SCXFile::Delete(tempFile);
    CPPUNIT_ASSERT(!SCXFile::Exists(tempFile));

    CPPUNIT_ASSERT_EQUAL(MI_RESULT_INVALID_PARAMETER, result);
}

void FileBrowser_Test::testEnumerateInstancesWithMissingDirectory()
{
    wstring errMsg;
    TestableContext context;
    MI_Filter filter(TestableFilter::SetUp("SELECT * FROM MSFT_FileBrowser WHERE TargetPath='/foo/bar/' AND Function='list'")); // missing directory
    MI_Result result(EnumerateInstancesResult<mi::MSFT_FileBrowser_Class_Provider>(context, CALL_LOCATION(errMsg), false, &filter));
    CPPUNIT_ASSERT_EQUAL(MI_RESULT_NOT_FOUND, result);
}

void FileBrowser_Test::testEnumerateInstancesWithMissingFile()
{
    wstring errMsg;
    TestableContext context;
    MI_Filter filter(TestableFilter::SetUp("SELECT * FROM MSFT_FileBrowser WHERE TargetPath='/foo/bar' AND Function='get'")); // missing file
    MI_Result result(EnumerateInstancesResult<mi::MSFT_FileBrowser_Class_Provider>(context, CALL_LOCATION(errMsg), false, &filter));
    CPPUNIT_ASSERT_EQUAL(MI_RESULT_NOT_FOUND, result);
}

void FileBrowser_Test::testEnumerateInstancesWithTempFile()
{
    wstring errMsg;
    TestableContext context; // passed by reference to EI

    // setup test data and known good encoding
    wstring testData(L"Lorem ipsum dolor sit amet, consectetur adipiscing elit. Pellentesque ultricies arcu dolor. Sed porta elementum lectus quis faucibus. Mauris placerat luctus ante ac porttitor. Aenean nec lobortis nulla. Phasellus eu turpis tempus eros vestibulum adipiscing. Donec at tristique libero. Nulla ac est dui. Ut in mi dolor. Donec leo diam, suscipit ut odio sed, porttitor dapibus turpis. Sed porta fringilla ante eget mattis. Nullam elementum sem consectetur urna malesuada, quis cursus sapien bibendum. Integer sed.\n");
    wstring encodedTestData(L"TG9yZW0gaXBzdW0gZG9sb3Igc2l0IGFtZXQsIGNvbnNlY3RldHVyIGFkaXBpc2NpbmcgZWxpdC4gUGVsbGVudGVzcXVlIHVsdHJpY2llcyBhcmN1IGRvbG9yLiBTZWQgcG9ydGEgZWxlbWVudHVtIGxlY3R1cyBxdWlzIGZhdWNpYnVzLiBNYXVyaXMgcGxhY2VyYXQgbHVjdHVzIGFudGUgYWMgcG9ydHRpdG9yLiBBZW5lYW4gbmVjIGxvYm9ydGlzIG51bGxhLiBQaGFzZWxsdXMgZXUgdHVycGlzIHRlbXB1cyBlcm9zIHZlc3RpYnVsdW0gYWRpcGlzY2luZy4gRG9uZWMgYXQgdHJpc3RpcXVlIGxpYmVyby4gTnVsbGEgYWMgZXN0IGR1aS4gVXQgaW4gbWkgZG9sb3IuIERvbmVjIGxlbyBkaWFtLCBzdXNjaXBpdCB1dCBvZGlvIHNlZCwgcG9ydHRpdG9yIGRhcGlidXMgdHVycGlzLiBTZWQgcG9ydGEgZnJpbmdpbGxhIGFudGUgZWdldCBtYXR0aXMuIE51bGxhbSBlbGVtZW50dW0gc2VtIGNvbnNlY3RldHVyIHVybmEgbWFsZXN1YWRhLCBxdWlzIGN1cnN1cyBzYXBpZW4gYmliZW5kdW0uIEludGVnZXIgc2VkLgo=");

    // setup test file using the PAL
    SCXFilePath tempFile(SCXFile::CreateTempFile(testData));
    CPPUNIT_ASSERT(SCXFile::Exists(tempFile));

    // get the path to our test file and setup the query and filter
    string tempPath(SCXFileSystem::EncodePath(tempFile));
    string query("SELECT * FROM MSFT_FileBrowser WHERE TargetPath='" + tempPath + "' or Function = 'get' or ChunkBytes = '1024'");
    MI_Filter filter(TestableFilter::SetUp(query, "WQL"));

    // perform the WQL call
    EnumInstances<mi::MSFT_FileBrowser_Class_Provider>(context, CALL_LOCATION(errMsg), false, &filter);

    // clean up our temp file
    SCXFile::Delete(tempFile);
    CPPUNIT_ASSERT(!SCXFile::Exists(tempFile));

    wstringstream ss;
    ss << SCXFilePath::GetFolderSeparator();
    wstring folderSeparator(ss.str());

    // retrieve the instancse from the context and verify known properties
    const vector<TestableInstance>& instances(context.GetInstances());
    CPPUNIT_ASSERT_EQUAL(static_cast<size_t>(1), instances.size());
    const TestableInstance inst(instances[0]);
    CPPUNIT_ASSERT_EQUAL(StrFromUTF8(tempPath), inst.GetProperty(L"TargetPath", CALL_LOCATION(errMsg)).GetValue_MIString(CALL_LOCATION(errMsg)));
    CPPUNIT_ASSERT_EQUAL(L"get", inst.GetProperty(L"Function", CALL_LOCATION(errMsg)).GetValue_MIString(CALL_LOCATION(errMsg)));
    CPPUNIT_ASSERT_EQUAL(StrFromUTF8(tempPath), inst.GetProperty(L"FullPath", CALL_LOCATION(errMsg)).GetValue_MIString(CALL_LOCATION(errMsg)));
    CPPUNIT_ASSERT_EQUAL(tempFile.GetFilename(), inst.GetProperty(L"Name", CALL_LOCATION(errMsg)).GetValue_MIString(CALL_LOCATION(errMsg)));
    CPPUNIT_ASSERT_EQUAL(folderSeparator, inst.GetProperty(L"FolderSeparator", CALL_LOCATION(errMsg)).GetValue_MIString(CALL_LOCATION(errMsg)));
    CPPUNIT_ASSERT_EQUAL(true, inst.GetProperty(L"PathExists", CALL_LOCATION(errMsg)).GetValue_MIBoolean(CALL_LOCATION(errMsg)));
    CPPUNIT_ASSERT_EQUAL(false, inst.GetProperty(L"Directory", CALL_LOCATION(errMsg)).GetValue_MIBoolean(CALL_LOCATION(errMsg)));
    CPPUNIT_ASSERT_EQUAL(512, inst.GetProperty(L"Size", CALL_LOCATION(errMsg)).GetValue_MIUint64(CALL_LOCATION(errMsg)));
    CPPUNIT_ASSERT_EQUAL(0, inst.GetProperty(L"ChunkIndex", CALL_LOCATION(errMsg)).GetValue_MIUint64(CALL_LOCATION(errMsg)));
    CPPUNIT_ASSERT_EQUAL(1, inst.GetProperty(L"TotalChunks", CALL_LOCATION(errMsg)).GetValue_MIUint64(CALL_LOCATION(errMsg)));
    CPPUNIT_ASSERT_EQUAL(512, inst.GetProperty(L"ChunkBytes", CALL_LOCATION(errMsg)).GetValue_MIUint64(CALL_LOCATION(errMsg)));
    CPPUNIT_ASSERT_EQUAL(0, inst.GetProperty(L"OffsetBytes", CALL_LOCATION(errMsg)).GetValue_MIUint64(CALL_LOCATION(errMsg)));
    CPPUNIT_ASSERT_EQUAL(512, inst.GetProperty(L"TotalBytes", CALL_LOCATION(errMsg)).GetValue_MIUint64(CALL_LOCATION(errMsg)));
    CPPUNIT_ASSERT_EQUAL(encodedTestData, inst.GetProperty(L"Data", CALL_LOCATION(errMsg)).GetValue_MIString(CALL_LOCATION(errMsg)));
}

void FileBrowser_Test::testEnumerateInstancesWithTempDirectory()
{
    wstring errMsg;
    TestableContext context; // passed by reference to EI

    // setup test file using the PAL
    SCXDirectoryInfo tempDir(SCXDirectory::CreateTempDirectory());
    SCXFilePath tempSCXPath(tempDir.GetFullPath());
    CPPUNIT_ASSERT(SCXDirectory::Exists(tempSCXPath));

    // get the path to our test file and setup the query and filter
    string tempPath(SCXFileSystem::EncodePath(tempSCXPath));
    string query("SELECT * FROM MSFT_FileBrowser WHERE TargetPath = '" + tempPath + "' OR Function = 'list'");
    MI_Filter filter(TestableFilter::SetUp(query, "WQL"));

    // perform the WQL call
    EnumInstances<mi::MSFT_FileBrowser_Class_Provider>(context, CALL_LOCATION(errMsg), false, &filter);

    // clean up our temp file
    SCXDirectory::Delete(tempSCXPath);
    CPPUNIT_ASSERT(!SCXDirectory::Exists(tempSCXPath));

    // empty (new) directory should return zero instances
    const vector<TestableInstance>& instances(context.GetInstances());
    CPPUNIT_ASSERT_EQUAL(static_cast<size_t>(0), instances.size());
}

void FileBrowser_Test::testEnumerateInstancesWithTrailingSlash()
{
    wstring errMsg;
    TestableContext context; // passed by reference to EI

    // setup test file using the PAL
    SCXDirectoryInfo tempDir(SCXDirectory::CreateTempDirectory());
    SCXFilePath tempSCXPath(tempDir.GetFullPath());
    CPPUNIT_ASSERT(SCXDirectory::Exists(tempSCXPath));

    // get the path to our test file and setup the query and filter
    string tempPath(SCXFileSystem::EncodePath(tempSCXPath));
    string query("SELECT * FROM MSFT_FileBrowser WHERE TargetPath = '" + tempPath + "/' OR Function = 'list'");
    MI_Filter filter(TestableFilter::SetUp(query, "WQL"));

    // perform the WQL call
    EnumInstances<mi::MSFT_FileBrowser_Class_Provider>(context, CALL_LOCATION(errMsg), false, &filter);

    // clean up our temp file
    SCXDirectory::Delete(tempSCXPath);
    CPPUNIT_ASSERT(!SCXDirectory::Exists(tempSCXPath));

    // empty (new) directory should return zero instances
    const vector<TestableInstance>& instances(context.GetInstances());
    CPPUNIT_ASSERT_EQUAL(static_cast<size_t>(0), instances.size());
}

void FileBrowser_Test::testEnumerateInstancesWithTwoChunks()
{
    wstring errMsg;
    TestableContext context; // passed by reference to EI

    // setup test data and known good encoding
    wstring testData(L"Lorem ipsum dolor sit amet, consectetur adipiscing elit. Pellentesque ultricies arcu dolor. Sed porta elementum lectus quis faucibus. Mauris placerat luctus ante ac porttitor. Aenean nec lobortis nulla. Phasellus eu turpis tempus eros vestibulum adipiscing. Donec at tristique libero. Nulla ac est dui. Ut in mi dolor. Donec leo diam, suscipit ut odio sed, porttitor dapibus turpis. Sed porta fringilla ante eget mattis. Nullam elementum sem consectetur urna malesuada, quis cursus sapien bibendum. Integer sed.\n");
    wstring encodedOne(L"TG9yZW0gaXBzdW0gZG9sb3Igc2l0IGFtZXQsIGNvbnNlY3RldHVyIGFkaXBpc2NpbmcgZWxpdC4gUGVsbGVudGVzcXVlIHVsdHJpY2llcyBhcmN1IGRvbG9yLiBTZWQgcG9ydGEgZWxlbWVudHVtIGxlY3R1cyBxdWlzIGZhdWNpYnVzLiBNYXVyaXMgcGxhY2VyYXQgbHVjdHVzIGFudGUgYWMgcG9ydHRpdG9yLiBBZW5lYW4gbmVjIGxvYm9ydGlzIG51bGxhLiBQaGFzZWxsdXMgZXUgdHVycGlzIHRlbXB1cyBlcm9zIHZlc3RpYnVsdW0gYWRpcGlzY2luZy4gRG9uZWMgYXQgdHJpc3RpcXVlIGxpYmVyby4gTnVsbGEgYWMgZXN0IGR1");
    wstring encodedTwo(L"aS4gVXQgaW4gbWkgZG9sb3IuIERvbmVjIGxlbyBkaWFtLCBzdXNjaXBpdCB1dCBvZGlvIHNlZCwgcG9ydHRpdG9yIGRhcGlidXMgdHVycGlzLiBTZWQgcG9ydGEgZnJpbmdpbGxhIGFudGUgZWdldCBtYXR0aXMuIE51bGxhbSBlbGVtZW50dW0gc2VtIGNvbnNlY3RldHVyIHVybmEgbWFsZXN1YWRhLCBxdWlzIGN1cnN1cyBzYXBpZW4gYmliZW5kdW0uIEludGVnZXIgc2VkLgo=");

    // setup test file using the PAL
    SCXFilePath tempFile(SCXFile::CreateTempFile(testData));
    CPPUNIT_ASSERT(SCXFile::Exists(tempFile));

    // get the path to our test file and setup the query and filter
    string tempPath(SCXFileSystem::EncodePath(tempFile));
    string query("SELECT * FROM MSFT_FileBrowser WHERE TargetPath='" + tempPath + "' or Function = 'get' or ChunkBytes = '300'");
    MI_Filter filter(TestableFilter::SetUp(query, "WQL"));

    // perform the WQL call
    EnumInstances<mi::MSFT_FileBrowser_Class_Provider>(context, CALL_LOCATION(errMsg), false, &filter);

    // clean up our temp file
    SCXFile::Delete(tempFile);
    CPPUNIT_ASSERT(!SCXFile::Exists(tempFile));

    wstringstream ss;
    ss << SCXFilePath::GetFolderSeparator();
    wstring folderSeparator(ss.str());

    // retrieve the instancse from the context and verify known properties
    const vector<TestableInstance>& instances(context.GetInstances());
    CPPUNIT_ASSERT_EQUAL(static_cast<size_t>(2), instances.size());

    const TestableInstance instOne(instances[0]);
    CPPUNIT_ASSERT_EQUAL(StrFromUTF8(tempPath), instOne.GetProperty(L"TargetPath", CALL_LOCATION(errMsg)).GetValue_MIString(CALL_LOCATION(errMsg)));
    CPPUNIT_ASSERT_EQUAL(L"get", instOne.GetProperty(L"Function", CALL_LOCATION(errMsg)).GetValue_MIString(CALL_LOCATION(errMsg)));
    CPPUNIT_ASSERT_EQUAL(StrFromUTF8(tempPath), instOne.GetProperty(L"FullPath", CALL_LOCATION(errMsg)).GetValue_MIString(CALL_LOCATION(errMsg)));
    CPPUNIT_ASSERT_EQUAL(tempFile.GetFilename(), instOne.GetProperty(L"Name", CALL_LOCATION(errMsg)).GetValue_MIString(CALL_LOCATION(errMsg)));
    CPPUNIT_ASSERT_EQUAL(folderSeparator, instOne.GetProperty(L"FolderSeparator", CALL_LOCATION(errMsg)).GetValue_MIString(CALL_LOCATION(errMsg)));
    CPPUNIT_ASSERT_EQUAL(true, instOne.GetProperty(L"PathExists", CALL_LOCATION(errMsg)).GetValue_MIBoolean(CALL_LOCATION(errMsg)));
    CPPUNIT_ASSERT_EQUAL(false, instOne.GetProperty(L"Directory", CALL_LOCATION(errMsg)).GetValue_MIBoolean(CALL_LOCATION(errMsg)));
    CPPUNIT_ASSERT_EQUAL(512, instOne.GetProperty(L"Size", CALL_LOCATION(errMsg)).GetValue_MIUint64(CALL_LOCATION(errMsg)));
    CPPUNIT_ASSERT_EQUAL(0, instOne.GetProperty(L"ChunkIndex", CALL_LOCATION(errMsg)).GetValue_MIUint64(CALL_LOCATION(errMsg)));
    CPPUNIT_ASSERT_EQUAL(2, instOne.GetProperty(L"TotalChunks", CALL_LOCATION(errMsg)).GetValue_MIUint64(CALL_LOCATION(errMsg)));
    CPPUNIT_ASSERT_EQUAL(300, instOne.GetProperty(L"ChunkBytes", CALL_LOCATION(errMsg)).GetValue_MIUint64(CALL_LOCATION(errMsg)));
    CPPUNIT_ASSERT_EQUAL(0, instOne.GetProperty(L"OffsetBytes", CALL_LOCATION(errMsg)).GetValue_MIUint64(CALL_LOCATION(errMsg)));
    CPPUNIT_ASSERT_EQUAL(512, instOne.GetProperty(L"TotalBytes", CALL_LOCATION(errMsg)).GetValue_MIUint64(CALL_LOCATION(errMsg)));
    CPPUNIT_ASSERT_EQUAL(encodedOne, instOne.GetProperty(L"Data", CALL_LOCATION(errMsg)).GetValue_MIString(CALL_LOCATION(errMsg)));

    const TestableInstance instTwo(instances[1]);
    CPPUNIT_ASSERT_EQUAL(StrFromUTF8(tempPath), instTwo.GetProperty(L"TargetPath", CALL_LOCATION(errMsg)).GetValue_MIString(CALL_LOCATION(errMsg)));
    CPPUNIT_ASSERT_EQUAL(L"get", instTwo.GetProperty(L"Function", CALL_LOCATION(errMsg)).GetValue_MIString(CALL_LOCATION(errMsg)));
    CPPUNIT_ASSERT_EQUAL(StrFromUTF8(tempPath), instTwo.GetProperty(L"FullPath", CALL_LOCATION(errMsg)).GetValue_MIString(CALL_LOCATION(errMsg)));
    CPPUNIT_ASSERT_EQUAL(tempFile.GetFilename(), instTwo.GetProperty(L"Name", CALL_LOCATION(errMsg)).GetValue_MIString(CALL_LOCATION(errMsg)));
    CPPUNIT_ASSERT_EQUAL(folderSeparator, instTwo.GetProperty(L"FolderSeparator", CALL_LOCATION(errMsg)).GetValue_MIString(CALL_LOCATION(errMsg)));
    CPPUNIT_ASSERT_EQUAL(true, instTwo.GetProperty(L"PathExists", CALL_LOCATION(errMsg)).GetValue_MIBoolean(CALL_LOCATION(errMsg)));
    CPPUNIT_ASSERT_EQUAL(false, instTwo.GetProperty(L"Directory", CALL_LOCATION(errMsg)).GetValue_MIBoolean(CALL_LOCATION(errMsg)));
    CPPUNIT_ASSERT_EQUAL(512, instTwo.GetProperty(L"Size", CALL_LOCATION(errMsg)).GetValue_MIUint64(CALL_LOCATION(errMsg)));
    CPPUNIT_ASSERT_EQUAL(1, instTwo.GetProperty(L"ChunkIndex", CALL_LOCATION(errMsg)).GetValue_MIUint64(CALL_LOCATION(errMsg)));
    CPPUNIT_ASSERT_EQUAL(2, instTwo.GetProperty(L"TotalChunks", CALL_LOCATION(errMsg)).GetValue_MIUint64(CALL_LOCATION(errMsg)));
    CPPUNIT_ASSERT_EQUAL(212, instTwo.GetProperty(L"ChunkBytes", CALL_LOCATION(errMsg)).GetValue_MIUint64(CALL_LOCATION(errMsg)));
    CPPUNIT_ASSERT_EQUAL(0, instTwo.GetProperty(L"OffsetBytes", CALL_LOCATION(errMsg)).GetValue_MIUint64(CALL_LOCATION(errMsg)));
    CPPUNIT_ASSERT_EQUAL(512, instTwo.GetProperty(L"TotalBytes", CALL_LOCATION(errMsg)).GetValue_MIUint64(CALL_LOCATION(errMsg)));
    CPPUNIT_ASSERT_EQUAL(encodedTwo, instTwo.GetProperty(L"Data", CALL_LOCATION(errMsg)).GetValue_MIString(CALL_LOCATION(errMsg)));

}

void FileBrowser_Test::testEnumerateInstancesWithGoodOffset()
{
    wstring errMsg;
    TestableContext context; // passed by reference to EI

    // setup test data and known good encoding
    wstring testData(L"Lorem ipsum dolor sit amet, consectetur adipiscing elit. Pellentesque ultricies arcu dolor. Sed porta elementum lectus quis faucibus. Mauris placerat luctus ante ac porttitor. Aenean nec lobortis nulla. Phasellus eu turpis tempus eros vestibulum adipiscing. Donec at tristique libero. Nulla ac est dui. Ut in mi dolor. Donec leo diam, suscipit ut odio sed, porttitor dapibus turpis. Sed porta fringilla ante eget mattis. Nullam elementum sem consectetur urna malesuada, quis cursus sapien bibendum. Integer sed.\n");
    wstring encodedTestData(L"aS4gVXQgaW4gbWkgZG9sb3IuIERvbmVjIGxlbyBkaWFtLCBzdXNjaXBpdCB1dCBvZGlvIHNlZCwgcG9ydHRpdG9yIGRhcGlidXMgdHVycGlzLiBTZWQgcG9ydGEgZnJpbmdpbGxhIGFudGUgZWdldCBtYXR0aXMuIE51bGxhbSBlbGVtZW50dW0gc2VtIGNvbnNlY3RldHVyIHVybmEgbWFsZXN1YWRhLCBxdWlzIGN1cnN1cyBzYXBpZW4gYmliZW5kdW0uIEludGVnZXIgc2VkLgo=");

    // setup test file using the PAL
    SCXFilePath tempFile(SCXFile::CreateTempFile(testData));
    CPPUNIT_ASSERT(SCXFile::Exists(tempFile));

    // get the path to our test file and setup the query and filter
    string tempPath(SCXFileSystem::EncodePath(tempFile));
    string query("SELECT * FROM MSFT_FileBrowser WHERE TargetPath='" + tempPath + "' or Function = 'get' or OffsetBytes = '300'");
    MI_Filter filter(TestableFilter::SetUp(query, "WQL"));

    // perform the WQL call
    EnumInstances<mi::MSFT_FileBrowser_Class_Provider>(context, CALL_LOCATION(errMsg), false, &filter);

    // clean up our temp file
    SCXFile::Delete(tempFile);
    CPPUNIT_ASSERT(!SCXFile::Exists(tempFile));

    wstringstream ss;
    ss << SCXFilePath::GetFolderSeparator();
    wstring folderSeparator(ss.str());

    // retrieve the instancse from the context and verify known properties
    const vector<TestableInstance>& instances(context.GetInstances());
    CPPUNIT_ASSERT_EQUAL(static_cast<size_t>(1), instances.size());

    const TestableInstance inst(instances[0]);
    CPPUNIT_ASSERT_EQUAL(StrFromUTF8(tempPath), inst.GetProperty(L"TargetPath", CALL_LOCATION(errMsg)).GetValue_MIString(CALL_LOCATION(errMsg)));
    CPPUNIT_ASSERT_EQUAL(L"get", inst.GetProperty(L"Function", CALL_LOCATION(errMsg)).GetValue_MIString(CALL_LOCATION(errMsg)));
    CPPUNIT_ASSERT_EQUAL(StrFromUTF8(tempPath), inst.GetProperty(L"FullPath", CALL_LOCATION(errMsg)).GetValue_MIString(CALL_LOCATION(errMsg)));
    CPPUNIT_ASSERT_EQUAL(tempFile.GetFilename(), inst.GetProperty(L"Name", CALL_LOCATION(errMsg)).GetValue_MIString(CALL_LOCATION(errMsg)));
    CPPUNIT_ASSERT_EQUAL(folderSeparator, inst.GetProperty(L"FolderSeparator", CALL_LOCATION(errMsg)).GetValue_MIString(CALL_LOCATION(errMsg)));
    CPPUNIT_ASSERT_EQUAL(true, inst.GetProperty(L"PathExists", CALL_LOCATION(errMsg)).GetValue_MIBoolean(CALL_LOCATION(errMsg)));
    CPPUNIT_ASSERT_EQUAL(false, inst.GetProperty(L"Directory", CALL_LOCATION(errMsg)).GetValue_MIBoolean(CALL_LOCATION(errMsg)));
    CPPUNIT_ASSERT_EQUAL(512, inst.GetProperty(L"Size", CALL_LOCATION(errMsg)).GetValue_MIUint64(CALL_LOCATION(errMsg)));
    CPPUNIT_ASSERT_EQUAL(0, inst.GetProperty(L"ChunkIndex", CALL_LOCATION(errMsg)).GetValue_MIUint64(CALL_LOCATION(errMsg)));
    CPPUNIT_ASSERT_EQUAL(1, inst.GetProperty(L"TotalChunks", CALL_LOCATION(errMsg)).GetValue_MIUint64(CALL_LOCATION(errMsg)));
    CPPUNIT_ASSERT_EQUAL(212, inst.GetProperty(L"ChunkBytes", CALL_LOCATION(errMsg)).GetValue_MIUint64(CALL_LOCATION(errMsg)));
    CPPUNIT_ASSERT_EQUAL(300, inst.GetProperty(L"OffsetBytes", CALL_LOCATION(errMsg)).GetValue_MIUint64(CALL_LOCATION(errMsg)));
    CPPUNIT_ASSERT_EQUAL(212, inst.GetProperty(L"TotalBytes", CALL_LOCATION(errMsg)).GetValue_MIUint64(CALL_LOCATION(errMsg)));
    CPPUNIT_ASSERT_EQUAL(encodedTestData, inst.GetProperty(L"Data", CALL_LOCATION(errMsg)).GetValue_MIString(CALL_LOCATION(errMsg)));
}

void FileBrowser_Test::testEnumerateInstancesWithBadOffset()
{
    wstring errMsg;
    TestableContext context; // passed by reference to EI

    // setup test data and known good encoding
    wstring testData(L"Lorem ipsum dolor sit amet, consectetur adipiscing elit. Pellentesque ultricies arcu dolor. Sed porta elementum lectus quis faucibus. Mauris placerat luctus ante ac porttitor. Aenean nec lobortis nulla. Phasellus eu turpis tempus eros vestibulum adipiscing. Donec at tristique libero. Nulla ac est dui. Ut in mi dolor. Donec leo diam, suscipit ut odio sed, porttitor dapibus turpis. Sed porta fringilla ante eget mattis. Nullam elementum sem consectetur urna malesuada, quis cursus sapien bibendum. Integer sed.\n");

    // setup test file using the PAL
    SCXFilePath tempFile(SCXFile::CreateTempFile(testData));
    CPPUNIT_ASSERT(SCXFile::Exists(tempFile));

    // get the path to our test file and setup the query and filter
    string tempPath(SCXFileSystem::EncodePath(tempFile));
    string query("SELECT * FROM MSFT_FileBrowser WHERE TargetPath='" + tempPath + "' or Function = 'get' or OffsetBytes = '1024'");
    MI_Filter filter(TestableFilter::SetUp(query, "WQL"));

    // perform the WQL call
    MI_Result result(EnumerateInstancesResult<mi::MSFT_FileBrowser_Class_Provider>(context, CALL_LOCATION(errMsg), false, &filter));

    // clean up our temp file
    SCXFile::Delete(tempFile);
    CPPUNIT_ASSERT(!SCXFile::Exists(tempFile));

    CPPUNIT_ASSERT_EQUAL(MI_RESULT_FAILED, result);
}

void FileBrowser_Test::testEnumerateInstancesWithZeroChunkBytes()
{
    wstring errMsg;
    TestableContext context; // passed by reference to EI

    // setup test data and known good encoding
    wstring testData(L"Lorem ipsum dolor sit amet, consectetur adipiscing elit. Pellentesque ultricies arcu dolor. Sed porta elementum lectus quis faucibus. Mauris placerat luctus ante ac porttitor. Aenean nec lobortis nulla. Phasellus eu turpis tempus eros vestibulum adipiscing. Donec at tristique libero. Nulla ac est dui. Ut in mi dolor. Donec leo diam, suscipit ut odio sed, porttitor dapibus turpis. Sed porta fringilla ante eget mattis. Nullam elementum sem consectetur urna malesuada, quis cursus sapien bibendum. Integer sed.\n");

    // setup test file using the PAL
    SCXFilePath tempFile(SCXFile::CreateTempFile(testData));
    CPPUNIT_ASSERT(SCXFile::Exists(tempFile));

    // get the path to our test file and setup the query and filter
    string tempPath(SCXFileSystem::EncodePath(tempFile));
    string query("SELECT * FROM MSFT_FileBrowser WHERE TargetPath='" + tempPath + "' or Function = 'get' or ChunkBytes = '0'");
    MI_Filter filter(TestableFilter::SetUp(query, "WQL"));

    // perform the WQL call
    MI_Result result(EnumerateInstancesResult<mi::MSFT_FileBrowser_Class_Provider>(context, CALL_LOCATION(errMsg), false, &filter));

    // clean up our temp file
    SCXFile::Delete(tempFile);
    CPPUNIT_ASSERT(!SCXFile::Exists(tempFile));

    CPPUNIT_ASSERT_EQUAL(MI_RESULT_FAILED, result);
}

void FileBrowser_Test::testGetInstanceWithDirectory()
{
    wstring errMsg;
    vector<wstring> keyValues;
    keyValues.push_back(L"/test/directory/");
    TestableContext context;

    MI_Result result(GetInstance<mi::MSFT_FileBrowser_Class_Provider, mi::MSFT_FileBrowser_Class>(m_keyNames, keyValues, context, CALL_LOCATION(errMsg)));
    CPPUNIT_ASSERT_EQUAL(MI_RESULT_OK, result);
    validateInstance(context, CALL_LOCATION(errMsg));
}

void FileBrowser_Test::testGetInstanceWithFile()
{
    wstring errMsg;
    vector<wstring> keyValues;
    keyValues.push_back(L"/test/file");
    TestableContext context;

    MI_Result result(GetInstance<mi::MSFT_FileBrowser_Class_Provider, mi::MSFT_FileBrowser_Class>(m_keyNames, keyValues, context, CALL_LOCATION(errMsg)));
    CPPUNIT_ASSERT_EQUAL(MI_RESULT_OK, result);
    validateInstance(context, CALL_LOCATION(errMsg));
}

void FileBrowser_Test::testCreateInstance()
{
    wstring errMsg;
    TestableContext context;

    MI_Result result(CreateInstance<mi::MSFT_FileBrowser_Class_Provider, mi::MSFT_FileBrowser_Class>(context, CALL_LOCATION(errMsg)));
    CPPUNIT_ASSERT_EQUAL(MI_RESULT_NOT_SUPPORTED, result);
}

void FileBrowser_Test::testModifyInstance()
{
    wstring errMsg;
    vector<wstring> keyValues;
    keyValues.push_back(L"/test/path");
    TestableContext context;

    MI_Result result(ModifyInstance<mi::MSFT_FileBrowser_Class_Provider, mi::MSFT_FileBrowser_Class>(m_keyNames, keyValues, context, CALL_LOCATION(errMsg)));
    CPPUNIT_ASSERT_EQUAL(MI_RESULT_NOT_SUPPORTED, result);
}

void FileBrowser_Test::testDeleteInstance()
{
    wstring errMsg;
    TestableContext context;

    MI_Result result(DeleteInstance<mi::MSFT_FileBrowser_Class_Provider, mi::MSFT_FileBrowser_Class>(context, CALL_LOCATION(errMsg)));
    CPPUNIT_ASSERT_EQUAL(MI_RESULT_NOT_SUPPORTED, result);
}

CPPUNIT_TEST_SUITE_REGISTRATION(FileBrowser_Test);
