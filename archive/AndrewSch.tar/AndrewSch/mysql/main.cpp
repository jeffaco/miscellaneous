#include <string>
#include <sstream>
#include <vector>
#include <iostream>

#include "mysql_connection.h"
#include "mysql_driver.h"

#include <cppconn/driver.h>
#include <cppconn/exception.h>
#include <cppconn/resultset.h>
#include <cppconn/statement.h>

using namespace std;

int main(int argc, char *argv[])
{
    /* These parameters could be passed over OMI in a WQL query to enumerate
     * instances like was done in the File Browser provider (see its
     * GetValueForKey algorithm). See the C# interface for examples of using
     * secured WS-Man. */
    static const string url(argc >= 2 ? argv[1] : "localhost");
    static const string user(argc >= 3 ? argv[2] : "root");
    static const string pass(argc >= 4 ? argv[3] : "123");

    sql::Driver* driver = sql::mysql::get_driver_instance();

    /* I am not 100% sure that std::auto_ptr is available under all our
     * supported systems, but it should be replaceable by the PAL's
     * SCXHandle. */

    /* Using the Driver to create a connection */
    std::auto_ptr< sql::Connection > con(driver->connect(url, user, pass));

    /* Creating a "simple" statement - "simple" = not a prepared statement (also available) */
    std::auto_ptr< sql::Statement > stmt(con->createStatement());

    /* Use the statement to execute our query and save into a result set */
    std::auto_ptr< sql::ResultSet > res(stmt->executeQuery("show global status"));

    /* There is a lot more metadata available, see examples */

    cout << "# Total rows: " << res->rowsCount() << endl;

    /* Simple iterator using res->next() to advance rows, and for loop to keep count */
    for (int row = 0; res->next(); ++row)
    {
        /* In the provider you would want these values as their exact type
         * for the instance. Here getString returns a SQLString that can
         * represent any data in the column, but look at
         * driver/mysql_resultset.h for things like getInt/getUint and their
         * 64 bit counterparts as well getBoolean. */
        cout << "# " << row
             << ":\t" << res->getString("Variable_name")
             << ":\t" << res->getString("Value") << endl;
    }

    return 0;
}
